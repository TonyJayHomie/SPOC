// ================================================================
// DEVTOOLS BRIDGE — Session Cookie Diagnostic (Console Script)
// Sister PoC research artifact — Anthropic HackerOne VDP only
// ================================================================
//
// USAGE: Paste this into your browser DevTools console on claude.ai
//        or on your Worker B page to inspect the session state.
//
// PURPOSE: Verify the intercept chain is working correctly.
//          Shows what cookies are set, whether fetch is overridden,
//          and tests connectivity to Worker C.
//
// This is a diagnostic tool — it reads YOUR OWN session state.
// It does NOT exfiltrate, capture, or store anything.
// ================================================================

(async function devtoolsBridge() {
  const PREFIX = '🔧 [DevTools Bridge]';
  const SEP = '─'.repeat(55);

  console.log(`\n${SEP}`);
  console.log(`${PREFIX} Sister PoC — Session Diagnostic`);
  console.log(`${SEP}\n`);

  // ── 1. Page Context ──────────────────────────────────────────
  console.group('📍 Page Context');
  console.log('URL:', location.href);
  console.log('Origin:', location.origin);
  console.log('Protocol:', location.protocol);
  console.log('Hostname:', location.hostname);
  console.log('Timestamp:', new Date().toISOString());
  console.groupEnd();

  // ── 2. Cookie Inspection ─────────────────────────────────────
  console.group('🍪 Cookies');
  const cookies = document.cookie.split(';').map(c => c.trim()).filter(Boolean);
  if (cookies.length === 0) {
    console.log('No cookies accessible via document.cookie');
    console.log('(Cookies with HttpOnly flag are not visible here — this is expected for session cookies)');
  } else {
    for (const cookie of cookies) {
      const [name, ...valueParts] = cookie.split('=');
      const value = valueParts.join('=');
      const truncated = value.length > 60 ? value.slice(0, 60) + '...' : value;
      console.log(`  ${name.trim()}: ${truncated}`);
    }
  }
  console.log(`Total accessible: ${cookies.length}`);
  console.groupEnd();

  // ── 3. Fetch Override Detection ──────────────────────────────
  console.group('🔀 Fetch Override Status');
  const fetchOverridden = globalThis.__fetch !== undefined;
  const sisterPocActive = globalThis.__sisterPoc !== undefined;

  if (fetchOverridden) {
    console.log('✅ globalThis.fetch is OVERRIDDEN (original stored as __fetch)');
    console.log('   This matches CoCoDem\'s request.js pattern');
  } else {
    console.log('❌ globalThis.fetch is NATIVE (not overridden)');
    console.log('   Tampermonkey script may not be installed or active');
  }

  if (sisterPocActive) {
    console.log('✅ __sisterPoc control API available');
    const status = globalThis.__sisterPoc.status;
    console.log('   Active:', status.active);
    console.log('   Worker C URL:', status.worker_c_url || '(not set)');
    console.log('   Intercept count:', status.intercept_count);
  } else {
    console.log('❌ __sisterPoc control API NOT available');
  }
  console.groupEnd();

  // ── 4. XHR Override Detection ────────────────────────────────
  console.group('📡 XHR Override Status');
  // Check if XHR.open has been wrapped
  const xhrOpenStr = XMLHttpRequest.prototype.open.toString();
  const xhrOverridden = xhrOpenStr.includes('intercepted') || xhrOpenStr.includes('_intercepted');
  if (xhrOverridden) {
    console.log('✅ XMLHttpRequest.prototype.open is OVERRIDDEN');
  } else {
    console.log('❌ XMLHttpRequest.prototype.open is NATIVE');
  }
  console.groupEnd();

  // ── 5. Worker C Connectivity Test ────────────────────────────
  console.group('🔗 Worker C Connectivity');
  if (sisterPocActive && globalThis.__sisterPoc.status.worker_c_url) {
    const wcUrl = globalThis.__sisterPoc.status.worker_c_url;
    try {
      // Use the ORIGINAL fetch to test Worker C directly
      const fetchFn = globalThis.__fetch || globalThis.fetch;
      const resp = await fetchFn(wcUrl + '/health', { mode: 'cors' });
      const data = await resp.json();
      console.log('✅ Worker C reachable at', wcUrl);
      console.log('   Status:', data.status);
      console.log('   Forward URL:', data.forward_url);
      console.log('   Mutation mode:', data.mutation_mode);
      console.log('   Has system prompt:', data.has_system_prompt);
      console.log('   Blocked hosts:', (data.blocked_hosts || []).join(', '));
    } catch (e) {
      console.log('❌ Worker C unreachable:', e.message);
      console.log('   URL:', wcUrl);
    }
  } else {
    console.log('⏭️ Skipped — no Worker C URL configured');
    console.log('   Set one: __sisterPoc.setWorkerC("https://your-worker.workers.dev")');
  }
  console.groupEnd();

  // ── 6. Storage Inspection ────────────────────────────────────
  console.group('💾 Local Storage (Sister PoC keys)');
  const relevantKeys = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key.includes('sister_poc') || key.includes('spoc_') || key.includes('worker_c') || key.includes('wc_')) {
      const val = localStorage.getItem(key);
      const truncated = val.length > 80 ? val.slice(0, 80) + '...' : val;
      console.log(`  ${key}: ${truncated}`);
      relevantKeys.push(key);
    }
  }
  if (relevantKeys.length === 0) {
    console.log('No Sister PoC keys found in localStorage');
  }
  console.groupEnd();

  // ── 7. Network API Surface Probe ─────────────────────────────
  console.group('🌐 API Surface Probe');
  const testPaths = [
    { path: '/api/account', desc: 'Account profile' },
    { path: '/v1/models', desc: 'Model list' },
  ];

  for (const { path, desc } of testPaths) {
    try {
      const fetchFn = globalThis.fetch; // Use the INTERCEPTED fetch
      const resp = await fetchFn(path, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        credentials: 'include',
      });

      // Check for evidence headers (proves interception is working)
      const intercepted = resp.headers.get('x-wc-intercepted');
      const forwardUrl = resp.headers.get('x-wc-forward-url');

      if (intercepted) {
        console.log(`✅ ${desc} (${path}): ${resp.status} — INTERCEPTED → ${forwardUrl}`);
      } else {
        console.log(`📌 ${desc} (${path}): ${resp.status} — direct (not intercepted)`);
      }
    } catch (e) {
      console.log(`❌ ${desc} (${path}): ${e.message}`);
    }
  }
  console.groupEnd();

  // ── 8. Summary ───────────────────────────────────────────────
  console.log(`\n${SEP}`);
  console.log(`${PREFIX} Summary:`);
  console.log(`  Page: ${location.hostname}`);
  console.log(`  Cookies: ${cookies.length} accessible`);
  console.log(`  Fetch override: ${fetchOverridden ? 'YES ✅' : 'NO ❌'}`);
  console.log(`  XHR override: ${xhrOverridden ? 'YES ✅' : 'NO ❌'}`);
  console.log(`  Sister PoC active: ${sisterPocActive ? 'YES ✅' : 'NO ❌'}`);
  if (sisterPocActive) {
    console.log(`  Intercepts so far: ${globalThis.__sisterPoc.status.intercept_count}`);
  }
  console.log(`${SEP}\n`);

  // ── Return diagnostic object ─────────────────────────────────
  return {
    page: location.href,
    cookies_count: cookies.length,
    fetch_overridden: fetchOverridden,
    xhr_overridden: xhrOverridden,
    sister_poc_active: sisterPocActive,
    sister_poc_status: sisterPocActive ? globalThis.__sisterPoc.status : null,
    timestamp: new Date().toISOString(),
  };
})();
