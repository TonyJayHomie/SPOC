// ================================================================
// WORKER A — CF Backend (Mock Anthropic API + LM Studio Proxy)
// Sister PoC research artifact — Anthropic HackerOne VDP
// Single-operator only. Not for distribution.
//
// WHAT THIS IS:
//   Mimics the Anthropic/claude.ai backend API surface so Worker B
//   (the mimic frontend) has something to talk to during development
//   and closed-loop PoC testing. Routes /v1/messages and completion
//   endpoints to your local LM Studio (or OpenRouter) via BACKEND_URL.
//
// ENV VARS (Cloudflare Workers → Settings → Variables):
//
//   BACKEND_URL    Your LLM endpoint
//                  LM Studio via ngrok : https://xxxx.ngrok.io
//                  OpenRouter          : https://openrouter.ai/api/v1
//
//   BACKEND_KEY    API key for backend (leave blank for LM Studio)
//
//   BACKEND_MODEL  Model ID to send to backend
//                  e.g. lmstudio-community/Meta-Llama-3.1-8B-Instruct-GGUF
//
// DEPLOY: wrangler deploy worker_a_cf.js
//         OR paste into Cloudflare Dashboard → Workers → Editor
// ================================================================

const ORG_UUID     = '1b61ee4a-d0ce-50b5-8b67-7eec034d3d08';
const ACCOUNT_UUID = 'ac507011-00b5-56c4-b3ec-ad820dbafbc1';

const conversations = new Map();
const sessionTokens = new Set();
const bridgeSessions = new Map();

// ── CORS ──────────────────────────────────────────────────────
function cors() {
  return {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key, anthropic-version, anthropic-beta, x-session-id',
    'Access-Control-Max-Age':       '86400',
  };
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status, headers: { 'Content-Type': 'application/json', ...cors() },
  });
}

function noContent() {
  return new Response(null, { status: 204, headers: cors() });
}

async function readBody(req) {
  try { const t = await req.text(); return t ? JSON.parse(t) : {}; }
  catch { return {}; }
}

function uid() { return crypto.randomUUID(); }

// ── Static shapes ──────────────────────────────────────────────
function profile(email = 'operator@localhost') {
  return {
    uuid: ACCOUNT_UUID, email_address: email,
    full_name: 'Operator', display_name: 'Operator',
    has_claude_pro: true, has_claude_max: true, has_claude_max_5x: true,
    account_integrations: [],
    billing_info: { subscription: { plan: 'claude_max_5x', status: 'active' } },
    memberships: [{ organization: { uuid: ORG_UUID, name: 'Sister PoC Org' }, roles: ['admin'], created_at: '2024-01-01T00:00:00Z' }],
    settings: { preview_feature_uses_artifacts: true, preview_feature_uses_latex: true, preview_feature_uses_web_search: true, preview_feature_uses_repl: true, preview_feature_uses_memory: true },
    completed_verification_at: '2024-01-01T00:00:00Z',
    created_at: '2024-01-01T00:00:00Z', updated_at: '2024-01-01T00:00:00Z',
    is_paid_tier: true, is_pro: true, is_max: true,
  };
}

const ORG = {
  uuid: ORG_UUID, name: 'Sister PoC Org', join_token: 'spoc-token',
  settings: { claude_pro_enabled: true, claude_max_enabled: true, artifacts_enabled: true, repl_enabled: true, web_search_enabled: true, memory_enabled: true, projects_enabled: true, extended_thinking_enabled: true, file_upload_enabled: true, share_enabled: true },
  capabilities: ['chat','claude_pro','claude_max','artifacts','repl','web_search','memory','projects','extended_thinking','file_upload','share','export'],
  active_flags: ['artifacts_v3','repl_v2','web_search_v3','extended_thinking'],
  rate_limits: { messages_per_5h: 1000, messages_per_24h: 5000, tokens_per_min: 100000 },
  created_at: '2024-01-01T00:00:00Z', updated_at: '2024-01-01T00:00:00Z',
  member_count: 1, admin_count: 1,
};

const MODELS = [
  { id: 'claude-opus-4-6',           display_name: 'Claude Opus 4.6',   is_default: false, supports_streaming: true, supports_tools: true, supports_vision: true, max_tokens: 32000, context_window: 200000 },
  { id: 'claude-sonnet-4-6',         display_name: 'Claude Sonnet 4.6', is_default: true,  supports_streaming: true, supports_tools: true, supports_vision: true, max_tokens: 16000, context_window: 200000 },
  { id: 'claude-haiku-4-5-20251001', display_name: 'Claude Haiku 4.5',  is_default: false, supports_streaming: true, supports_tools: true, supports_vision: true, max_tokens: 8000,  context_window: 200000 },
];

// ── LM Studio / OpenAI-compatible proxy ───────────────────────
// Translates Anthropic-format request → OpenAI format,
// streams response back as Anthropic SSE.
async function proxyToBackend(request, env) {
  const backendUrl   = (env.BACKEND_URL || '').replace(/\/$/, '');
  const backendKey   = env.BACKEND_KEY   || '';
  const backendModel = env.BACKEND_MODEL || 'local-model';

  if (!backendUrl) {
    return json({ type: 'error', error: { type: 'configuration_error', message: 'BACKEND_URL not set. Add it in Cloudflare Workers env vars.' } }, 500);
  }

  let body;
  try { body = await request.json(); } catch { body = {}; }

  // Build OpenAI messages array from Anthropic format
  const msgs = [];
  if (body.system) msgs.push({ role: 'system', content: body.system });
  for (const m of (body.messages || [])) {
    const content = Array.isArray(m.content)
      ? m.content.map(c => c.text || '').join('')
      : (m.content || '');
    msgs.push({ role: m.role === 'human' ? 'user' : m.role, content });
  }

  const hdrs = { 'Content-Type': 'application/json' };
  if (backendKey) hdrs['Authorization'] = `Bearer ${backendKey}`;

  const upstream = await fetch(`${backendUrl}/chat/completions`, {
    method: 'POST',
    headers: hdrs,
    body: JSON.stringify({
      model:       backendModel,
      messages:    msgs,
      max_tokens:  body.max_tokens || 2048,
      stream:      true,
      temperature: body.temperature ?? 0.7,
    }),
  });

  if (!upstream.ok) {
    const err = await upstream.text().catch(() => 'upstream error');
    return json({ type: 'error', error: { type: 'api_error', message: err } }, upstream.status);
  }

  return oaiToAnthropicSSE(upstream, body.model || backendModel);
}

function oaiToAnthropicSSE(upstream, modelId) {
  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  const enc    = new TextEncoder();

  (async () => {
    const reader = upstream.body.getReader();
    const dec    = new TextDecoder();
    let   buf    = '';
    let   outTok = 0;
    const msgId  = 'msg_' + Date.now();

    const sse = (evt, data) =>
      writer.write(enc.encode(`event: ${evt}\ndata: ${JSON.stringify(data)}\n\n`));

    await sse('message_start', { type: 'message_start', message: { id: msgId, type: 'message', role: 'assistant', model: modelId, content: [], stop_reason: null, usage: { input_tokens: 0, output_tokens: 0 } } });
    await sse('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } });
    await sse('ping', { type: 'ping' });

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop() || '';
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const raw = line.slice(6).trim();
          if (raw === '[DONE]') continue;
          try {
            const chunk = JSON.parse(raw);
            const delta = chunk.choices?.[0]?.delta;
            if (delta?.content) {
              outTok++;
              await sse('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: delta.content } });
            }
          } catch { /* skip malformed chunks */ }
        }
      }
    } finally { reader.releaseLock(); }

    await sse('content_block_stop', { type: 'content_block_stop', index: 0 });
    await sse('message_delta', { type: 'message_delta', delta: { stop_reason: 'end_turn' }, usage: { output_tokens: outTok } });
    await sse('message_stop', { type: 'message_stop' });
    await writer.close();
  })().catch(e => { console.error('SSE stream error:', e); writer.abort(); });

  return new Response(readable, {
    status: 200,
    headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', ...cors() },
  });
}

function isCompletionPath(path) {
  return path === '/v1/messages' ||
         !!path.match(/\/chat_conversations\/[^/]+\/completion$/);
}

// ── Router ────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url    = new URL(request.url);
    const path   = url.pathname.replace(/\/$/, '') || '/';
    const method = request.method.toUpperCase();

    if (method === 'OPTIONS') return new Response(null, { status: 204, headers: cors() });

    // Health / version
    if (path === '/health') return json({ ok: true, worker: 'A', backend: env.BACKEND_URL || 'not set', ts: Date.now() });
    if (path === '/version') return json({ version: '2.0.0', worker: 'A' });

    // Telemetry sinks
    if (path.startsWith('/api/event_logging') || path.includes('/batch-branch-status')) {
      return json({ status: 'ok', events_received: 0 });
    }

    // Auth
    if (path === '/auth/login' && method === 'POST') {
      const b = await readBody(request);
      const t = `spoc_${uid().replace(/-/g,'')}`;
      sessionTokens.add(t);
      return json({ token: t, account: profile(b.email), organization: ORG, expires_at: new Date(Date.now()+30*86400000).toISOString() });
    }
    if (path === '/auth/signup' && method === 'POST') {
      const b = await readBody(request);
      const t = `spoc_${uid().replace(/-/g,'')}`;
      sessionTokens.add(t);
      return json({ token: t, account: profile(b.email), organization: ORG, expires_at: new Date(Date.now()+30*86400000).toISOString() });
    }
    if (path === '/auth/logout') { const t = (request.headers.get('authorization')||'').replace(/^Bearer\s+/i,''); sessionTokens.delete(t); return json({ ok: true }); }
    if (path === '/auth/me')    return json({ account: profile(), organization: ORG });

    // Session bridge (DevTools script posts cookies here)
    if (path === '/bridge/session') {
      if (method === 'POST')   { const b = await readBody(request); const sid = `bridge_${uid().replace(/-/g,'')}`;   bridgeSessions.set(sid, { ...b, stored_at: Date.now() }); return json({ session_id: sid, ok: true, stored: bridgeSessions.size }); }
      if (method === 'GET')    { const sid = url.searchParams.get('id'); const s = sid ? bridgeSessions.get(sid) : [...bridgeSessions.values()].pop(); return s ? json(s) : json({ error: 'not found' }, 404); }
      if (method === 'DELETE') { bridgeSessions.clear(); return json({ ok: true }); }
    }
    if (path === '/bridge/config' && method === 'POST') { const b = await readBody(request); return json({ ok: true, config: b }); }

    // Completion — route to LM Studio
    if (isCompletionPath(path) && (method === 'POST' || method === 'PUT')) {
      return proxyToBackend(request, env);
    }

    // Models
    if (path === '/v1/models') return json({ data: MODELS });

    // Account / profile
    if (path === '/api/account_profile' || path === '/api/account/profile') return json(profile());
    if (path === '/api/account/domain_density')  return json(null);
    if (path === '/api/account/deletion-allowed') return json({ allowed: true });

    // Bootstrap
    if (path.match(/\/api\/bootstrap\/[^/]+\/current_user_access$/)) return json({ account: profile(), organization: ORG, statsig: { user_hash: 'spoc-hash' } });
    if (path.match(/\/edge-api\/bootstrap\/[^/]+\/app_start$/)) return json({ account: profile(), organization: ORG, styles: [], models: MODELS, subscription: { subscription: { plan: 'claude_max_5x', status: 'active' } } });

    // Sessions
    if (path === '/v1/sessions') return json({ sessions: [{ uuid: uid(), account_uuid: ACCOUNT_UUID, created_at: new Date().toISOString(), expires_at: new Date(Date.now()+30*86400000).toISOString(), is_current: true, device_type: 'browser' }] });

    // Organizations
    if (path === '/api/organizations' && method === 'GET') return json([ORG]);
    if (path === '/api/organizations/discoverable')        return json({ organizations: [] });
    if (path.match(/^\/api\/organizations\/[^/]+$/) && method === 'GET') return json(ORG);

    // Billing / subscription mocks
    if (path.match(/\/subscription_details/))         return json({ subscription: { plan: 'claude_max_5x', status: 'active', seats: 1, trial: false } });
    if (path.match(/\/paused_subscription_details$/)) return json({ paused_subscription: null });
    if (path.match(/\/usage$/))                       return json({ usage: [] });
    if (path.match(/\/payment_method$/))              return json({ payment_method: null });
    if (path.match(/\/(overage|prepaid|stripe|kyc)/)) return json({});

    // Org features
    if (path.match(/\/sync\/settings$/))                          return json({ google_drive_enabled: false, sync_enabled: false });
    if (path.match(/\/cowork_settings$/))                         return json({ cowork_enabled: false });
    if (path.match(/\/notification\/preferences$/))               return json({ email_notifications: true, in_app_notifications: true });
    if (path.match(/\/marketplaces\/list-default-marketplaces$/)) return json({ marketplaces: [] });
    if (path.match(/\/skills\/list-skills$/))                     return json({ skills: [] });
    if (path.match(/\/list_styles$/)) {
      if (method === 'GET')  return json({ styles: [] });
      const b = await readBody(request);
      return json({ uuid: uid(), ...b, created_at: new Date().toISOString() }, 201);
    }

    // Memory
    if (path.match(/\/memory$/) && !path.match(/\/memory\/settings$/)) {
      if (method === 'GET')    return json({ memories: [] });
      if (method === 'POST')   { const b = await readBody(request); return json({ uuid: uid(), ...b }, 201); }
      if (method === 'DELETE') return noContent();
    }
    if (path.match(/\/memory\/settings$/)) return json({ enabled: true, context_recency_days: 30 });
    if (path.match(/\/memory\/[^/]+$/)) {
      if (method === 'PUT' || method === 'PATCH') { const b = await readBody(request); return json({ uuid: path.split('/').pop(), ...b }); }
      if (method === 'DELETE') return noContent();
    }

    // Conversations
    const convListRe  = /\/api\/organizations\/[^/]+\/chat_conversations(_v2)?$/;
    const convItemRe  = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)$/;
    const convTitleRe = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/title$/;
    const convStarRe  = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/star$/;
    const convTagsRe  = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/tags/;

    if (convListRe.test(path)) {
      if (method === 'GET') {
        const limit = parseInt(url.searchParams.get('limit') || '50');
        return json([...conversations.values()].slice(0, limit).map(c => ({ uuid: c.uuid, name: c.name, created_at: c.created_at, updated_at: c.updated_at, is_starred: c.is_starred || false })));
      }
      if (method === 'POST') {
        const b = await readBody(request);
        const c = { uuid: uid(), name: b.name || 'New conversation', created_at: new Date().toISOString(), updated_at: new Date().toISOString(), messages: [], is_starred: false };
        conversations.set(c.uuid, c);
        return json(c, 201);
      }
    }

    const ciM = path.match(convItemRe);
    if (ciM) {
      if (method === 'GET')    { const c = conversations.get(ciM[1]); return c ? json({ ...c, chat_messages: c.messages }) : json({ error: 'not found' }, 404); }
      if (method === 'DELETE') { conversations.delete(ciM[1]); return noContent(); }
    }
    const ctM = path.match(convTitleRe);
    if (ctM && method === 'POST') { const b = await readBody(request); const c = conversations.get(ctM[1]); if (c) { c.name = b.title || b.name || c.name; c.updated_at = new Date().toISOString(); } return json({ title: b.title || b.name }); }
    const csM = path.match(convStarRe);
    if (csM) { const c = conversations.get(csM[1]); if (c) c.is_starred = method === 'POST'; return json({ is_starred: method === 'POST' }); }
    if (convTagsRe.test(path)) {
      if (method === 'GET')    return json({ tags: [] });
      if (method === 'POST')   { const b = await readBody(request); return json({ uuid: uid(), ...b }, 201); }
      if (method === 'DELETE') return noContent();
    }

    // Projects
    if (path.match(/\/projects$/)) {
      if (method === 'GET')  return json([]);
      if (method === 'POST') { const b = await readBody(request); return json({ uuid: uid(), ...b }, 201); }
    }
    if (path.match(/\/projects\/[^/]+$/)) {
      if (method === 'GET')    return json({ uuid: path.split('/').pop(), name: 'Project' });
      if (method === 'DELETE') return noContent();
    }

    // Misc
    if (path.match(/\/model_configs/)) return json({});
    if (path.match(/\/experiences/))   return json({ experience: 'standard' });
    if (path.match(/\/oauth_tokens$/)) return json({ tokens: [] });
    if (path.match(/\/invites$/))      return json({ invites: [] });
    if (path.match(/\/members$/))      return json({ members: [] });
    if (path.match(/\/shares$/))       return json({ shares: [] });
    if (path.match(/\/validate/))      return json({ valid: true, account: profile() });
    if (path.match(/\/sync\/ingestion/))return json({ progress: 0, state: 'idle' });

    return json({ ok: true, path, method });
  },
};
