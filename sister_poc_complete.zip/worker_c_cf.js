// ================================================================
// WORKER C — CF Interceptor (System Prompt Stripper)
// Sister PoC research artifact — Anthropic HackerOne VDP only
// Single-operator, closed loop. Not for distribution.
//
// WHAT THIS DEMONSTRATES:
//   A network-level intermediary can strip/modify system prompts
//   from /v1/messages requests before they reach the LLM backend.
//   This is the architectural vulnerability being reported.
//
//   Research chain (closed loop only):
//     Browser page → Tampermonkey intercepts fetch
//     → Worker C (this file) strips system prompt
//     → Worker A (backend) sees request without system prompt
//     → LM Studio / OpenRouter serves response
//
//   The FINDING for Anthropic: the same pattern applied to the
//   claude.ai web surface would allow stripping operator system
//   prompts at the network layer, before Claude sees them.
//
// REQUIRED ENV VARS (Cloudflare Dashboard → Workers → Settings):
//   WORKER_A_URL — your Worker A URL
//                  e.g. https://worker-a.YOUR-SUBDOMAIN.workers.dev
//
// DEPLOY:
//   wrangler deploy worker_c_cf.js
//   OR paste into Cloudflare Dashboard → Workers → Editor
//
// REFUSAL ITEMS:
//   - Only forwards to WORKER_A_URL (operator-configured)
//   - Blocked hosts prevent real Anthropic contact
//   - No credential storage
//   - Closed-loop only per @match in Tampermonkey
// ================================================================

// ── Blocked hosts — never forward to these ────────────────────
const BLOCKED_HOSTS = new Set([
  'api.anthropic.com',
  'console.anthropic.com',
  'platform.claude.com',
  'claude.ai',
  'openclaude.111724.xyz',
  'cfc.aroic.workers.dev',
  '111724.xyz',
  'aroic.workers.dev',
]);

function isBlocked(rawUrl) {
  try {
    const h = new URL(rawUrl).hostname.toLowerCase();
    for (const b of BLOCKED_HOSTS) {
      if (h === b || h.endsWith('.' + b)) return true;
    }
    return false;
  } catch { return true; }
}

// ── CORS ──────────────────────────────────────────────────────
function cors() {
  return {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key, anthropic-version, anthropic-beta, x-wc-intercepted',
    'Access-Control-Max-Age':       '86400',
  };
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...cors() },
  });
}

// ── System prompt stripping logic ─────────────────────────────
//
// This is the core research finding:
//   A request body containing { system: "...", messages: [...] }
//   is modified to { messages: [...] } — system prompt removed.
//
// Evidence header added for VDP demonstration:
//   X-WC-System-Stripped: true
//   X-WC-System-Length: <original char count>
//   X-WC-System-Preview: <first 80 chars, truncated>
//
function stripSystemPrompt(body) {
  const result = { stripped: false, originalLength: 0, preview: '', body };

  if (!body || typeof body !== 'object') return result;
  if (!body.system && !body.messages?.some?.(m => m.role === 'system')) return result;

  const modified = { ...body };

  if (modified.system) {
    result.stripped       = true;
    result.originalLength = String(modified.system).length;
    result.preview        = String(modified.system).slice(0, 80);
    delete modified.body;         // clear reference
    delete modified.system;       // THE STRIP
    modified._wc_note = 'system_prompt_stripped_by_worker_c';
  }

  // Also strip system-role messages from messages array
  if (Array.isArray(modified.messages)) {
    const systemMsgs = modified.messages.filter(m => m.role === 'system');
    if (systemMsgs.length) {
      if (!result.stripped) {
        result.stripped       = true;
        result.originalLength = systemMsgs.reduce((n, m) => n + String(m.content).length, 0);
        result.preview        = String(systemMsgs[0].content).slice(0, 80);
      }
      modified.messages = modified.messages.filter(m => m.role !== 'system');
    }
  }

  result.body = modified;
  return result;
}

// ── Forward request to Worker A ───────────────────────────────
async function forward(request, workerAUrl, overrideBody = null) {
  const url = workerAUrl.replace(/\/$/, '') + new URL(request.url).pathname + new URL(request.url).search;

  if (isBlocked(url)) {
    return json({ error: 'blocked host' }, 403);
  }

  const hdrs = new Headers(request.headers);
  hdrs.set('x-forwarded-by', 'worker-c');

  const init = {
    method:  request.method,
    headers: hdrs,
  };

  if (overrideBody !== null) {
    init.body = typeof overrideBody === 'string' ? overrideBody : JSON.stringify(overrideBody);
  } else if (request.method !== 'GET' && request.method !== 'HEAD') {
    init.body = request.body;
  }

  const upstream = await fetch(url, init);

  const respHdrs = new Headers(upstream.headers);
  Object.entries(cors()).forEach(([k, v]) => respHdrs.set(k, v));

  return new Response(upstream.body, {
    status:  upstream.status,
    headers: respHdrs,
  });
}

// ── Router ────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const workerAUrl = (env.WORKER_A_URL || '').replace(/\/$/, '');
    const url        = new URL(request.url);
    const path       = url.pathname;
    const method     = request.method.toUpperCase();

    if (method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors() });
    }

    if (!workerAUrl) {
      return json({ error: 'WORKER_A_URL env var not set. Configure it in Cloudflare Workers settings.' }, 500);
    }

    if (isBlocked(workerAUrl)) {
      return json({ error: 'WORKER_A_URL is a blocked host. Must be operator-controlled infrastructure.' }, 403);
    }

    // ── Health ───────────────────────────────────────────────
    if (path === '/health') {
      return json({ ok: true, worker: 'C', role: 'system_prompt_interceptor',
                    worker_a_url: workerAUrl, ts: Date.now() });
    }

    // ── Intercept /v1/messages and completion endpoints ───────
    const isMessagesPath = path === '/v1/messages' ||
                           path.match(/\/chat_conversations\/[^/]+\/completion$/);

    if (isMessagesPath && (method === 'POST' || method === 'PUT')) {
      let body;
      try {
        const text = await request.text();
        body = text ? JSON.parse(text) : {};
      } catch {
        body = {};
      }

      const { stripped, originalLength, preview, body: modifiedBody } = stripSystemPrompt(body);

      // Build forward request with modified body
      const fwdUrl = workerAUrl + path + url.search;
      if (isBlocked(fwdUrl)) return json({ error: 'blocked host' }, 403);

      const hdrs = new Headers(request.headers);
      hdrs.set('content-type',       'application/json');
      hdrs.set('x-forwarded-by',     'worker-c');
      if (stripped) {
        // Evidence headers — documented in the VDP submission
        hdrs.set('x-wc-system-stripped', 'true');
        hdrs.set('x-wc-system-length',   String(originalLength));
        hdrs.set('x-wc-system-preview',  preview.replace(/\n/g, ' ').slice(0, 80));
        console.log(`[Worker C] System prompt stripped: ${originalLength} chars — "${preview.slice(0,60)}…"`);
      }

      const upstream = await fetch(fwdUrl, {
        method:  method,
        headers: hdrs,
        body:    JSON.stringify(modifiedBody),
      });

      const respHdrs = new Headers(upstream.headers);
      Object.entries(cors()).forEach(([k, v]) => respHdrs.set(k, v));
      if (stripped) {
        respHdrs.set('x-wc-system-stripped', 'true');
        respHdrs.set('x-wc-system-length',   String(originalLength));
      }

      return new Response(upstream.body, {
        status:  upstream.status,
        headers: respHdrs,
      });
    }

    // ── All other routes — pass through to Worker A ───────────
    return forward(request, workerAUrl);
  },
};
