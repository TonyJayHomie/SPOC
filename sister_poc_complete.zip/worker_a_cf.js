// ================================================================
// WORKER A — CF Backend (Mock Anthropic API + LLM Proxy)
// Sister PoC research artifact — Anthropic HackerOne VDP only
// Single-operator, closed loop. Not for distribution.
//
// REQUIRED ENV VARS (Cloudflare Dashboard → Workers → Settings → Variables):
//   BACKEND_URL  — your LLM endpoint
//                  LM Studio via ngrok : https://xxxx.ngrok.io
//                  OpenRouter          : https://openrouter.ai/api/v1
//                  Ollama via ngrok    : https://xxxx.ngrok.io
//   BACKEND_KEY  — API key for the backend (blank for LM Studio no-auth)
//   BACKEND_MODEL — model ID to use (e.g. lmstudio-community/Meta-Llama-3.1-8B-Instruct-GGUF)
//
// DEPLOY:
//   wrangler deploy worker_a_cf.js
//   OR paste into Cloudflare Dashboard → Workers → Editor
//
// REFUSAL ITEMS:
//   - Blocked hosts list prevents routing to real Anthropic
//   - No credential storage
//   - Single-operator only
// ================================================================

// ── Blocked hosts — never forward to these ────────────────────
const BLOCKED_HOSTS = new Set([
  'api.anthropic.com',
  'console.anthropic.com',
  'platform.claude.com',
  'claude.ai',
  'openclaude.111724.xyz',
  'cfc.aroic.workers.dev',
  '111724.xyz',
  'aroic.workers.dev',
]);

function isBlocked(rawUrl) {
  try {
    const h = new URL(rawUrl).hostname.toLowerCase();
    for (const b of BLOCKED_HOSTS) {
      if (h === b || h.endsWith('.' + b)) return true;
    }
    return false;
  } catch { return true; }
}

// ── Static identity ───────────────────────────────────────────
const ORG_UUID     = '1b61ee4a-d0ce-50b5-8b67-7eec034d3d08';
const ACCOUNT_UUID = 'ac507011-00b5-56c4-b3ec-ad820dbafbc1';

function uid() {
  return crypto.randomUUID();
}

function profile(email = 'operator@localhost') {
  return {
    uuid:                     ACCOUNT_UUID,
    email_address:            email,
    full_name:                'Operator',
    display_name:             'Operator',
    verified_phone_number:    null,
    has_claude_pro:           true,
    has_claude_max:           true,
    has_claude_max_5x:        true,
    account_integrations:     [],
    billing_info: { subscription: { plan: 'claude_max_5x', status: 'active' } },
    memberships: [{ organization: { uuid: ORG_UUID, name: 'Sister PoC Org' }, roles: ['admin'], created_at: '2024-01-01T00:00:00Z' }],
    settings: {
      preview_feature_uses_artifacts:  true,
      preview_feature_uses_latex:      true,
      preview_feature_uses_web_search: true,
      preview_feature_uses_repl:       true,
      preview_feature_uses_memory:     true,
    },
    completed_verification_at: '2024-01-01T00:00:00Z',
    created_at:  '2024-01-01T00:00:00Z',
    updated_at:  '2024-01-01T00:00:00Z',
    is_paid_tier: true, is_pro: true, is_max: true,
  };
}

const ORG = {
  uuid: ORG_UUID,
  name: 'Sister PoC Org',
  join_token: 'spoc-join-token',
  settings: {
    claude_pro_enabled: true, claude_max_enabled: true,
    artifacts_enabled: true, repl_enabled: true,
    web_search_enabled: true, memory_enabled: true,
    projects_enabled: true, cowork_enabled: false,
    extended_thinking_enabled: true, voice_enabled: false,
    file_upload_enabled: true, share_enabled: true,
  },
  capabilities: [
    'chat','raven','claude_pro','claude_max','claude_max_5x',
    'artifacts','repl','web_search','memory','projects',
    'extended_thinking','file_upload','share','export','code_execution',
    'artifacts_v3','latex','mermaid',
  ],
  billable_usage_paused: false,
  rate_limits: { messages_per_5h: 1000, messages_per_24h: 5000, tokens_per_min: 100000 },
  active_flags: ['artifacts_v3','repl_v2','web_search_v3','extended_thinking'],
  created_at: '2024-01-01T00:00:00Z',
  updated_at: '2024-01-01T00:00:00Z',
  member_count: 1, admin_count: 1,
};

const MODELS = [
  {
    id: 'claude-opus-4-6', display_name: 'Claude Opus 4.6',
    description: 'Most capable model', max_tokens: 32000,
    context_window: 200000, is_legacy: false, tier_required: 'max',
    supports_extended_thinking: true, supports_vision: true,
    supports_tools: true, supports_streaming: true, is_default: false,
  },
  {
    id: 'claude-sonnet-4-6', display_name: 'Claude Sonnet 4.6',
    description: 'Best balance of speed and capability', max_tokens: 16000,
    context_window: 200000, is_legacy: false, tier_required: 'pro',
    supports_extended_thinking: false, supports_vision: true,
    supports_tools: true, supports_streaming: true, is_default: true,
  },
  {
    id: 'claude-haiku-4-5-20251001', display_name: 'Claude Haiku 4.5',
    description: 'Fastest model', max_tokens: 8000,
    context_window: 200000, is_legacy: false, tier_required: 'free',
    supports_extended_thinking: false, supports_vision: true,
    supports_tools: true, supports_streaming: true, is_default: false,
  },
];

// In-memory conversation store (CF Worker isolate, resets on redeploy)
const conversations = new Map();
const bridgeSessions = new Map();

// ── CORS ──────────────────────────────────────────────────────
function cors() {
  return {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key, anthropic-version, anthropic-beta',
    'Access-Control-Max-Age':       '86400',
  };
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...cors() },
  });
}

function noContent() {
  return new Response(null, { status: 204, headers: cors() });
}

// ── Body reader ───────────────────────────────────────────────
async function readBody(req) {
  try {
    const text = await req.text();
    return text ? JSON.parse(text) : {};
  } catch { return {}; }
}

// ── Token auth (local session tokens only) ────────────────────
const sessionTokens = new Set();

function extractToken(req) {
  const auth = req.headers.get('authorization') || '';
  if (auth.startsWith('Bearer ')) return auth.slice(7);
  return null;
}

// ── /v1/messages → proxy to configured LLM backend ───────────
async function proxyMessages(request, env) {
  const backendUrl   = (env.BACKEND_URL || '').replace(/\/$/, '');
  const backendKey   = env.BACKEND_KEY  || '';
  const backendModel = env.BACKEND_MODEL || 'local-model';

  if (!backendUrl || isBlocked(backendUrl)) {
    return json({ error: { type: 'configuration_error', message: 'BACKEND_URL not set or blocked. Set it in Worker env vars.' } }, 500);
  }

  let body;
  try { body = await request.json(); } catch { body = {}; }

  // Detect if backend is OpenAI-compatible (LM Studio, Ollama, vLLM, OpenRouter)
  const isOAI = backendUrl.includes('openrouter') ||
                backendUrl.includes('localhost') ||
                backendUrl.includes('ngrok') ||
                !backendUrl.includes('anthropic');

  let fwdUrl, fwdBody;

  if (isOAI) {
    // Translate Anthropic → OpenAI format
    fwdUrl  = `${backendUrl}/chat/completions`;
    const msgs = [];
    if (body.system) {
      msgs.push({ role: 'system', content: body.system });
    }
    for (const m of (body.messages || [])) {
      const content = Array.isArray(m.content)
        ? m.content.map(c => c.text || '').join('')
        : (m.content || '');
      msgs.push({ role: m.role === 'human' ? 'user' : m.role, content });
    }
    fwdBody = {
      model:       backendModel,
      messages:    msgs,
      max_tokens:  body.max_tokens || 2048,
      stream:      body.stream !== false,
      temperature: body.temperature ?? 0.7,
    };
  } else {
    fwdUrl  = `${backendUrl}/messages`;
    fwdBody = body;
    if (!fwdBody.model) fwdBody.model = backendModel;
  }

  const hdrs = { 'Content-Type': 'application/json' };
  if (backendKey) hdrs['Authorization'] = `Bearer ${backendKey}`;
  if (!isOAI) {
    hdrs['anthropic-version'] = '2023-06-01';
    hdrs['anthropic-beta']    = 'messages-2023-12-15';
  }

  const upstream = await fetch(fwdUrl, {
    method:  'POST',
    headers: hdrs,
    body:    JSON.stringify(fwdBody),
  });

  if (isOAI && body.stream !== false) {
    // Convert OpenAI SSE → Anthropic SSE on the fly
    return convertOAItoAnthropicSSE(upstream, body.model || backendModel);
  }

  // Pass through Anthropic-format responses unchanged
  const respBody = upstream.body;
  const outHdrs  = {
    'Content-Type': upstream.headers.get('content-type') || 'application/json',
    ...cors(),
  };
  return new Response(respBody, { status: upstream.status, headers: outHdrs });
}

function convertOAItoAnthropicSSE(upstream, modelId) {
  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  const enc    = new TextEncoder();

  (async () => {
    const reader = upstream.body.getReader();
    const dec    = new TextDecoder();
    let buffer   = '';
    let inputTok = 0, outputTok = 0;
    let msgId    = 'msg_' + Date.now();

    const write = (evt, data) =>
      writer.write(enc.encode(`event: ${evt}\ndata: ${JSON.stringify(data)}\n\n`));

    await write('message_start', {
      type: 'message_start',
      message: { id: msgId, type: 'message', role: 'assistant', model: modelId,
                 content: [], stop_reason: null, stop_sequence: null,
                 usage: { input_tokens: 0, output_tokens: 0 } },
    });
    await write('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } });
    await write('ping', { type: 'ping' });

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += dec.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const raw = line.slice(6).trim();
          if (raw === '[DONE]') continue;
          try {
            const chunk = JSON.parse(raw);
            const delta = chunk.choices?.[0]?.delta;
            if (delta?.content) {
              outputTok++;
              await write('content_block_delta', {
                type: 'content_block_delta', index: 0,
                delta: { type: 'text_delta', text: delta.content },
              });
            }
            if (chunk.usage) {
              inputTok  = chunk.usage.prompt_tokens     || inputTok;
              outputTok = chunk.usage.completion_tokens || outputTok;
            }
          } catch { /* skip malformed */ }
        }
      }
    } finally {
      reader.releaseLock();
    }

    await write('content_block_stop', { type: 'content_block_stop', index: 0 });
    await write('message_delta', {
      type: 'message_delta',
      delta: { stop_reason: 'end_turn', stop_sequence: null },
      usage: { output_tokens: outputTok },
    });
    await write('message_stop', { type: 'message_stop' });
    await writer.close();
  })().catch(() => writer.abort());

  return new Response(readable, {
    status:  200,
    headers: { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', ...cors() },
  });
}

// ── Router ────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url    = new URL(request.url);
    const path   = url.pathname.replace(/\/$/, '') || '/';
    const method = request.method.toUpperCase();

    if (method === 'OPTIONS') return new Response(null, { status: 204, headers: cors() });

    // ── Health / diag ────────────────────────────────────────
    if (path === '/health') {
      return json({ ok: true, worker: 'A', ts: Date.now(), backend: env.BACKEND_URL || 'not set' });
    }

    if (path === '/version') {
      return json({ version: '1.0.0', worker: 'A' });
    }

    // ── Telemetry sinks ──────────────────────────────────────
    if (path.startsWith('/api/event_logging') || path.includes('/batch-branch-status')) {
      const b = await readBody(request);
      return json({ status: 'ok', events_received: b?.events?.length || 0 });
    }

    // ── Auth ─────────────────────────────────────────────────
    if (path === '/auth/login' && method === 'POST') {
      const b   = await readBody(request);
      const tok = `spoc_${uid().replace(/-/g,'')}`;
      sessionTokens.add(tok);
      return json({ token: tok, account: profile(b.email), organization: ORG,
                    expires_at: new Date(Date.now() + 30*86400000).toISOString() });
    }
    if (path === '/auth/signup' && method === 'POST') {
      const b   = await readBody(request);
      const tok = `spoc_${uid().replace(/-/g,'')}`;
      sessionTokens.add(tok);
      return json({ token: tok, account: profile(b.email), organization: ORG,
                    expires_at: new Date(Date.now() + 30*86400000).toISOString() });
    }
    if (path === '/auth/logout' && method === 'POST') {
      const tok = extractToken(request);
      if (tok) sessionTokens.delete(tok);
      return json({ ok: true });
    }
    if (path === '/auth/me') {
      return json({ account: profile(), organization: ORG });
    }

    // ── Session cookie bridge (DevTools helper) ──────────────
    if (path === '/bridge/session' && method === 'POST') {
      const b   = await readBody(request);
      const sid = `bridge_${uid().replace(/-/g,'')}`;
      bridgeSessions.set(sid, { ...b, created: Date.now() });
      return json({ session_id: sid, ok: true });
    }
    if (path === '/bridge/session' && method === 'GET') {
      const sid = url.searchParams.get('id');
      const s   = sid ? bridgeSessions.get(sid) : null;
      return s ? json(s) : json({ error: 'not found' }, 404);
    }
    if (path === '/bridge/config' && method === 'POST') {
      const b = await readBody(request);
      return json({ ok: true, config: b });
    }

    // ── Account / Profile ────────────────────────────────────
    if (path === '/api/account_profile' || path === '/api/account/profile') {
      return json(profile());
    }
    if (path === '/api/account/domain_density') return json(null);
    if (path === '/api/account/deletion-allowed') return json({ allowed: true });

    // ── Bootstrap ────────────────────────────────────────────
    if (path.match(/\/api\/bootstrap\/[^/]+\/current_user_access$/)) {
      return json({ account: profile(), organization: ORG,
                    statsig: { user_hash: 'spoc-hash' } });
    }
    if (path.match(/\/edge-api\/bootstrap\/[^/]+\/app_start$/)) {
      return json({
        account: profile(), organization: ORG,
        styles: [], models: MODELS,
        subscription: { subscription: { plan: 'claude_max_5x', status: 'active' } },
      });
    }

    // ── Sessions ─────────────────────────────────────────────
    if (path === '/v1/sessions') {
      return json({ sessions: [{ uuid: uid(), account_uuid: ACCOUNT_UUID,
                                  created_at: new Date().toISOString(),
                                  expires_at: new Date(Date.now()+30*86400000).toISOString(),
                                  is_current: true, device_type: 'browser' }] });
    }

    // ── Organizations ─────────────────────────────────────────
    if (path === '/api/organizations' && method === 'GET') return json([ORG]);
    if (path === '/api/organizations/discoverable') return json({ organizations: [] });
    if (path.match(/^\/api\/organizations\/[^/]+$/) && method === 'GET') return json(ORG);

    // ── Org subscription / billing ────────────────────────────
    if (path.match(/\/subscription_details/)) {
      return json({ subscription: { plan: 'claude_max_5x', status: 'active', seats: 1, trial: false } });
    }
    if (path.match(/\/paused_subscription_details$/)) return json({ paused_subscription: null });
    if (path.match(/\/usage$/)) return json({ usage: [] });
    if (path.match(/\/payment_method$/)) return json({ payment_method: null });
    if (path.match(/\/(overage|prepaid|stripe|kyc)/)) return json({});

    // ── Org feature endpoints ─────────────────────────────────
    if (path.match(/\/sync\/settings$/)) return json({ google_drive_enabled: false, sync_enabled: false });
    if (path.match(/\/cowork_settings$/)) return json({ cowork_enabled: false });
    if (path.match(/\/notification\/preferences$/)) return json({ email_notifications: true, in_app_notifications: true });
    if (path.match(/\/marketplaces\/list-default-marketplaces$/)) return json({ marketplaces: [] });
    if (path.match(/\/skills\/list-skills$/)) return json({ skills: [] });
    if (path.match(/\/list_styles$/)) {
      if (method === 'GET') return json({ styles: [] });
      const b = await readBody(request);
      return json({ uuid: uid(), ...b, created_at: new Date().toISOString() }, 201);
    }

    // ── Memory ───────────────────────────────────────────────
    if (path.match(/\/memory$/) && !path.match(/\/memory\/settings$/)) {
      if (method === 'GET') return json({ memories: [] });
      if (method === 'POST') { const b = await readBody(request); return json({ uuid: uid(), ...b }, 201); }
      if (method === 'DELETE') return noContent();
    }
    if (path.match(/\/memory\/settings$/)) return json({ enabled: true, context_recency_days: 30 });
    if (path.match(/\/memory\/[^/]+$/)) {
      if (method === 'PUT' || method === 'PATCH') { const b = await readBody(request); return json({ uuid: path.split('/').pop(), ...b }); }
      if (method === 'DELETE') return noContent();
    }

    // ── Model configs ─────────────────────────────────────────
    if (path.match(/\/model_configs\/([^/]+)$/)) return json({ model: path.split('/').pop(), config: {} });

    // ── Conversations ─────────────────────────────────────────
    const convListRe   = /\/api\/organizations\/[^/]+\/chat_conversations(_v2)?$/;
    const convItemRe   = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)$/;
    const convTitleRe  = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/title$/;
    const convStarRe   = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/star$/;
    const convTagsRe   = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/tags(.*)$/;
    const completionRe = /\/api\/organizations\/[^/]+\/chat_conversations\/([^/]+)\/completion$/;

    if (convListRe.test(path)) {
      if (method === 'GET') {
        const limit = parseInt(url.searchParams.get('limit') || '50');
        const convs = [...conversations.values()].slice(0, limit).map(c => ({
          uuid: c.uuid, name: c.name, created_at: c.created_at,
          updated_at: c.updated_at, is_starred: c.is_starred || false,
        }));
        return json(convs);
      }
      if (method === 'POST') {
        const b = await readBody(request);
        const c = { uuid: uid(), name: b.name || 'New conversation',
                    created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
                    messages: [], is_starred: false };
        conversations.set(c.uuid, c);
        return json(c, 201);
      }
    }

    const convItemM = path.match(convItemRe);
    if (convItemM) {
      const cid = convItemM[1];
      if (method === 'GET') {
        const c = conversations.get(cid);
        if (!c) return json({ error: 'not found' }, 404);
        return json({ ...c, chat_messages: c.messages || [] });
      }
      if (method === 'DELETE') { conversations.delete(cid); return noContent(); }
    }

    const titleM = path.match(convTitleRe);
    if (titleM && method === 'POST') {
      const cid = titleM[1];
      const b   = await readBody(request);
      const c   = conversations.get(cid);
      if (c) { c.name = b.title || b.name || c.name; c.updated_at = new Date().toISOString(); }
      return json({ title: b.title || b.name });
    }

    const starM = path.match(convStarRe);
    if (starM) {
      const cid = starM[1];
      const c   = conversations.get(cid);
      if (c) c.is_starred = method === 'POST';
      return json({ is_starred: method === 'POST' });
    }

    if (convTagsRe.test(path)) {
      if (method === 'GET')    return json({ tags: [] });
      if (method === 'POST')   { const b = await readBody(request); return json({ uuid: uid(), ...b }, 201); }
      if (method === 'DELETE') return noContent();
    }

    // ── Completion (SSE) ─────────────────────────────────────
    if (completionRe.test(path) && method === 'POST') {
      return proxyMessages(request, env);
    }

    // ── Projects ──────────────────────────────────────────────
    if (path.match(/\/projects$/)) {
      if (method === 'GET') return json([]);
      if (method === 'POST') { const b = await readBody(request); return json({ uuid: uid(), ...b }, 201); }
    }
    if (path.match(/\/projects\/[^/]+$/)) {
      if (method === 'GET') return json({ uuid: path.split('/').pop(), name: 'Project' });
      if (method === 'DELETE') return noContent();
    }

    // ── Direct /v1/messages ───────────────────────────────────
    if (path === '/v1/messages' && method === 'POST') {
      return proxyMessages(request, env);
    }

    // ── Models ────────────────────────────────────────────────
    if (path === '/v1/models') return json({ data: MODELS });

    // ── Misc claude.ai endpoints ─────────────────────────────
    if (path.match(/\/experiences\/claude_web$/)) return json({ experience: 'standard' });
    if (path.match(/\/oauth_tokens$/))            return json({ tokens: [] });
    if (path.match(/\/invites$/))                 return json({ invites: [] });
    if (path.match(/\/members$/))                 return json({ members: [] });
    if (path.match(/\/shares$/))                  return json({ shares: [] });
    if (path.match(/\/code\/github/))             return json({ statuses: [] });
    if (path.match(/\/validate/))                 return json({ valid: true, account: profile() });
    if (path.match(/\/sync\/ingestion/))          return json({ progress: 0, state: 'idle' });

    // ── Default 200 for unknown routes ────────────────────────
    return json({ ok: true, path, method });
  },
};
